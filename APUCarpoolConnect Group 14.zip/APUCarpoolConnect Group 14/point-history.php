<?php
include 'db.php';
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'student') {
    header("Location: login.php"); exit();
}

$student_id = $_SESSION['user_id'];


$historyQuery = "
    (SELECT 
        'Earned' as type, 
        NULL as amount, 
        r.departure_time as activity_date, 
        CONCAT('Carpool Reward (Ride ', r.ride_id, ')') as description,
        lp.latitude as p_lat, lp.longitude as p_lng, ld.latitude as d_lat, ld.longitude as d_lng
     FROM carpool_request_table cr
     JOIN rides_table r ON cr.ride_id = r.ride_id
     JOIN location_table lp ON r.pickup_id = lp.location_id
     JOIN location_table ld ON r.dropoff_id = ld.location_id
     WHERE cr.student_id = '$student_id' AND cr.status = 'approved')
    UNION ALL
    (SELECT 
        'Spent' as type, 
        v.point_cost as amount, 
        red.redemption_date as activity_date, 
        v.voucher_name as description,
        NULL as p_lat, NULL as p_lng, NULL as d_lat, NULL as d_lng
     FROM voucher_redemption_table red 
     JOIN voucher_list_table v ON red.voucher_id = v.voucher_id 
     WHERE red.user_id = '$student_id')
    ORDER BY activity_date DESC";

$historyResult = mysqli_query($conn, $historyQuery);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Point History - APU Carpool</title>
    <link rel="stylesheet" href="student.css">
    <style>
        .history-container { max-width: 800px; margin: 40px auto; padding: 20px; }
        .history-item { background: white; padding: 15px 25px; border-radius: 12px; margin-bottom: 10px; display: flex; justify-content: space-between; align-items: center; box-shadow: 0 2px 5px rgba(0,0,0,0.05); }
        .type-badge { padding: 5px 12px; border-radius: 20px; font-size: 0.8rem; font-weight: bold; text-transform: uppercase; }
        .earned { background: #e8f5e9; color: #2e7d32; }
        .spent { background: #ffebee; color: #c62828; }
        .earned-amt { color: #2e7d32; font-weight: bold; }
        .spent-amt { color: #c62828; font-weight: bold; }
    </style>
</head>
<body>
    <?php include 'student-header.php'; ?>

    <div class="history-container">
        <div style="display: flex; justify-content: space-between; align-items: center;">
            <h2>Eco-Point Transactions</h2>
            <a href="carbon-reward.php" style="text-decoration: none; color: #666; font-size: 0.9rem;">← Back to Rewards</a>
        </div>
        <p>A history of your environmental impact and rewards.</p>
        <hr style="border: 0; border-top: 1px solid #ddd; margin: 20px 0;">

        <?php if(mysqli_num_rows($historyResult) > 0): ?>
            <?php while($row = mysqli_fetch_assoc($historyResult)): 
                
                //Calculation of earned points
                if ($row['type'] == 'Earned') {
                    $dist = getEstimatedRoadDist($row['p_lat'], $row['p_lng'], $row['d_lat'], $row['d_lng']);
                    $displayAmount = calculateEcoPoints($dist);
                } else {
                    $displayAmount = $row['amount'];
                }
            ?>
            
                <div class="history-item">
                    <div>
                        <span class="type-badge <?= strtolower($row['type']) ?>"><?= $row['type'] ?></span>
                        <strong style="display: block; margin-top: 8px;"><?= htmlspecialchars($row['description']) ?></strong>
                        <small style="color:#888;"><?= date('d M Y, h:i A', strtotime($row['activity_date'])) ?></small>
                    </div>
                    <div class="<?= strtolower($row['type']) ?>-amt">
                        <?= ($row['type'] == 'Earned' ? '+' : '-') . number_format($displayAmount) ?> pts
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div style="text-align:center; padding: 40px; background: white; border-radius: 12px;">
                <p style="color:#999;">No transactions found yet. Start carpooling to earn points!</p>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>