<?php
include 'db.php';
session_start();

//Security Check
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'driver') {
    header("Location: login.php");
    exit();
}

$driver_id = $_SESSION['user_id'];

//Fetch Total Earnings
$totalQuery = "SELECT SUM(cr.fare) as total 
               FROM carpool_request_table cr
               JOIN rides_table r ON cr.ride_id = r.ride_id
               WHERE r.driver_id = '$driver_id' 
               AND r.ride_status = 'completed' 
               AND cr.status = 'approved'";
$totalRes = mysqli_query($conn, $totalQuery);
$totalEarned = mysqli_fetch_assoc($totalRes)['total'] ?? 0.00;

//Fetch Earnings for the Current Month
$monthQuery = "SELECT SUM(cr.fare) as month_total 
               FROM carpool_request_table cr
               JOIN rides_table r ON cr.ride_id = r.ride_id
               WHERE r.driver_id = '$driver_id' 
               AND r.ride_status = 'completed' 
               AND cr.status = 'approved'
               AND MONTH(r.departure_time) = MONTH(CURRENT_DATE())
               AND YEAR(r.departure_time) = YEAR(CURRENT_DATE())";
$monthEarned = mysqli_fetch_assoc(mysqli_query($conn, $monthQuery))['month_total'] ?? 0.00;

//Fetch Transaction History (Detailed list)
$historyQuery = "SELECT cr.fare, r.departure_time, lp.location_name as pickup, ld.location_name as dropoff, u.full_name as student_name
                 FROM carpool_request_table cr
                 JOIN rides_table r ON cr.ride_id = r.ride_id
                 JOIN user_table u ON cr.student_id = u.user_id
                 JOIN location_table lp ON r.pickup_id = lp.location_id
                 JOIN location_table ld ON r.dropoff_id = ld.location_id
                 WHERE r.driver_id = '$driver_id' 
                 AND r.ride_status = 'completed' 
                 AND cr.status = 'approved'
                 ORDER BY r.departure_time DESC";
$historyRes = mysqli_query($conn, $historyQuery);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Earnings - APU Carpool</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="driver.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body style="background: white !important; margin: 0;">

    <?php include 'driver-header.php'; ?>

    <div class="dashboard-container">
        <h1 style="color: #1e293b; margin-bottom: 25px;"><i class="fas fa-wallet" style="color: #38bdf8;"></i> My Earnings</h1>

        <div class="stats-grid">
            <div class="stat-card" style="border-bottom: 4px solid #22c55e;">
                <h3>Total Revenue</h3>
                <p style="font-size: 2rem; font-weight: 800; color: #1e293b;">RM <?= number_format($totalEarned, 2) ?></p>
            </div>
            <div class="stat-card" style="border-bottom: 4px solid #38bdf8;">
                <h3>This Month</h3>
                <p style="font-size: 2rem; font-weight: 800; color: #1e293b;">RM <?= number_format($monthEarned, 2) ?></p>
            </div>
            <div class="stat-card" style="border-bottom: 4px solid #f59e0b;">
                <h3>Total Trips Paid</h3>
                <p style="font-size: 2rem; font-weight: 800; color: #1e293b;"><?= mysqli_num_rows($historyRes) ?></p>
            </div>
        </div>

        <div class="ride-section" style="background: white; padding: 30px; border-radius: 15px; box-shadow: 0 4px 15px rgba(0,0,0,0.05);">
            <h2 style="margin-top: 0; color: #1e293b; border-bottom: 1px solid #f1f5f9; padding-bottom: 15px;">Transaction History</h2>
            
            <?php if(mysqli_num_rows($historyRes) > 0): ?>
                <table style="width: 100%; border-collapse: collapse; margin-top: 10px;">
                    <thead>
                        <tr style="text-align: left; color: #64748b; font-size: 0.9rem; text-transform: uppercase;">
                            <th style="padding: 15px;">Date</th>
                            <th style="padding: 15px;">Trip Details</th>
                            <th style="padding: 15px;">Student</th>
                            <th style="padding: 15px; text-align: right;">Amount</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($row = mysqli_fetch_assoc($historyRes)): ?>
                            <tr style="border-bottom: 1px solid #f1f5f9;">
                                <td style="padding: 15px; color: #1e293b;">
                                    <?= date('d M Y', strtotime($row['departure_time'])) ?>
                                </td>
                                <td style="padding: 15px;">
                                    <div style="font-weight: 600; font-size: 0.95rem;"><?= $row['pickup'] ?> → <?= $row['dropoff'] ?></div>
                                </td>
                                <td style="padding: 15px; color: #64748b;">
                                    <?= htmlspecialchars($row['student_name']) ?>
                                </td>
                                <td style="padding: 15px; text-align: right; font-weight: 700; color: #22c55e;">
                                    + RM <?= number_format($row['fare'], 2) ?>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div style="text-align: center; padding: 50px; color: #94a3b8;">
                    <i class="fas fa-receipt" style="font-size: 3rem; margin-bottom: 15px; opacity: 0.3;"></i>
                    <p>No earnings records found. Complete rides to start earning!</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>