<?php
include 'db.php';
session_start();

//Security Check
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'student') {
    header("Location: login.php");
    exit();
}

$student_id = $_SESSION['user_id'];

//Fetch all requests
$query = "SELECT rq.request_id, rq.status as request_status, rq.fare, rq.ride_id,
                 r.ride_status, r.departure_time, r.driver_id,
                 u.full_name as driver_name,
                 lp.location_name as pickup_name, lp.latitude as p_lat, lp.longitude as p_lng,
                 ld.location_name as dropoff_name, ld.latitude as d_lat, ld.longitude as d_lng,
                 (SELECT COUNT(*) FROM carpool_request_table WHERE ride_id = r.ride_id AND status = 'approved') as passenger_count
          FROM carpool_request_table rq
          JOIN rides_table r ON rq.ride_id = r.ride_id
          JOIN user_table u ON r.driver_id = u.user_id
          JOIN location_table lp ON r.pickup_id = lp.location_id
          JOIN location_table ld ON r.dropoff_id = ld.location_id
          WHERE rq.student_id = '$student_id'
          ORDER BY r.departure_time DESC";

$result = mysqli_query($conn, $query);

if (!$result) {
    die("Query Failed: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ride History - APU Carpool</title>
    <link rel="stylesheet" href="student.css">
    <style>
        .history-container { max-width: 900px; margin: 30px auto; padding: 20px; }
        .history-card { 
            background: white; border-radius: 12px; padding: 20px; 
            margin-bottom: 15px; display: flex; justify-content: space-between; 
            align-items: center; box-shadow: 0 4px 6px rgba(0,0,0,0.05); border-left: 6px solid #ddd;
        }
        .status-pending { border-left-color: #f1c40f; }   
        .status-accepted { border-left-color: #2ecc71; }  
        .status-completed { border-left-color: #3498db; } 
        .status-rejected { border-left-color: #e74c3c; }  
        .badge { padding: 5px 12px; border-radius: 20px; font-size: 0.8rem; font-weight: bold; text-transform: uppercase; }
        .badge-pending { background: #fef9c3; color: #854d0e; }
        .badge-accepted { background: #dcfce7; color: #166534; }
        .badge-completed { background: #e0f2fe; color: #0369a1; } 
        .badge-rejected { background: #fee2e2; color: #991b1b; }
        .btn-rate { 
            display:block; margin-top:10px; text-align:center; padding: 5px 10px; 
            font-size: 0.8rem; background: #f1c40f; color: #000; text-decoration: none; 
            border-radius: 5px; font-weight: bold;
        }
        .btn-rate:hover { background: #d4ac0d; }
    </style>
</head>
<body>

    <?php include 'student-header.php'; ?>

    <div class="history-container">
        <h2>Your Ride History</h2>
        <?php if(mysqli_num_rows($result) > 0): ?>
            <?php while($row = mysqli_fetch_assoc($result)): 
                $reqStatus = strtolower($row['request_status']);
                $rideStatus = strtolower($row['ride_status']);

                if ($rideStatus == 'completed') {
                    $displayStatus = 'Completed';
                    $badgeClass = 'badge-completed';
                    $cardBorder = 'status-completed';
                } elseif ($reqStatus == 'approved') {
                    $displayStatus = 'Active';
                    $badgeClass = 'badge-accepted';
                    $cardBorder = 'status-accepted';
                } else {
                    $displayStatus = ucfirst($reqStatus);
                    $badgeClass = 'badge-' . $reqStatus;
                    $cardBorder = 'status-' . $reqStatus;
                }

                //Use the road-adjusted distance function
                $dist = getEstimatedRoadDist($row['p_lat'], $row['p_lng'], $row['d_lat'], $row['d_lng']);
                
                //Use the fare calculation function
                $totalRouteCost = calculateTotalFare($dist);
                
                //Split by passengers
                $passengers = ($row['passenger_count'] > 0) ? $row['passenger_count'] : 1;
                $splitFare = $totalRouteCost / $passengers;
            ?>
                <div class="history-card <?= $cardBorder ?>">
                    <div>
                        <span style="font-size: 0.75rem; color: #999;">ID: <?= $row['request_id'] ?></span>
                        <h4 style="margin: 5px 0;"><?= $row['pickup_name'] ?> ➔ <?= $row['dropoff_name'] ?></h4>
                        <p style="margin: 0; font-size: 0.9rem;">
                            <strong>Driver:</strong> <?= $row['driver_name'] ?> 
                            <span style="color: #888; margin-left: 10px;">(<?= $passengers ?> Passenger<?= $passengers > 1 ? 's' : '' ?>)</span>
                        </p>
                    </div>
                    
                    <div style="text-align: right;">
                        <div class="badge <?= $badgeClass ?>"><?= $displayStatus ?></div>
                        
                        <div style="margin-top: 8px; font-weight: bold; color: #333;">RM <?= number_format($splitFare, 2) ?></div>
                        <div style="font-size: 0.7rem; color: #888;"><?= number_format($dist, 2) ?> km total</div>

                        <?php if($rideStatus == 'completed'): 
                            $curr_ride_id = $row['ride_id'];
                            $checkRating = mysqli_query($conn, "SELECT rating_id FROM ratings_table WHERE ride_id = '$curr_ride_id' AND student_id = '$student_id'");
                            
                            if(mysqli_num_rows($checkRating) == 0): ?>
                                <a href="rate-driver.php?ride_id=<?= $row['ride_id'] ?>&driver_id=<?= $row['driver_id'] ?>" class="btn-rate">⭐ Rate Driver</a>
                            <?php else: ?>
                                <div style="margin-top:10px; color:#27ae60; font-size:0.8rem; font-weight:bold;">✓ Rated</div>
                            <?php endif; ?>
                        <?php endif; ?>

                        <?php if($reqStatus == 'approved' && $rideStatus != 'completed'): ?>
                            <a href="ride-details.php?id=<?= $row['request_id'] ?>" 
                            class="btn student" 
                            style="display:block; margin-top:10px; text-align:center; padding: 5px 10px; font-size: 0.8rem;">
                            View Ride Details
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div style="text-align: center; padding: 50px; background: white; border-radius: 12px;">
                <p>You haven't requested any rides yet.</p>
                <a href="student-homepage.php" class="btn student">Find a Ride Now</a>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>