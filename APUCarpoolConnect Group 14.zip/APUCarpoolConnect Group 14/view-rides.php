<?php
include 'db.php';
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'student') exit(header("Location: login.php"));

$p_id = $_GET['pickup'] ?? '';
$d_id = $_GET['dropoff'] ?? '';

//Fetch route details
$locs = mysqli_query($conn, "SELECT * FROM location_table WHERE location_id IN ('$p_id', '$d_id')");
$locationData = [];
while($row = mysqli_fetch_assoc($locs)) $locationData[$row['location_id']] = $row;

//Safety check
if (isset($locationData[$p_id]) && isset($locationData[$d_id])) {
    $p = $locationData[$p_id];
    $d = $locationData[$d_id];


    //Get road-adjusted distance
    $dist = getEstimatedRoadDist($p['latitude'], $p['longitude'], $d['latitude'], $d['longitude']);
    
    //Use the centralized fare function instead of manual * 1.50
    $total_fare = calculateTotalFare($dist);
    
    //Get environmental impact to show on search results
    $eco_points = calculateEcoPoints($dist);
} else {
    header("Location: student-home.php");
    exit();
}

// Find matching rides
$rides = mysqli_query($conn, "SELECT r.*, u.full_name as driver FROM rides_table r JOIN user_table u ON r.driver_id = u.user_id WHERE r.pickup_id = '$p_id' AND r.dropoff_id = '$d_id' AND r.ride_status = 'active' AND r.total_seats > 0");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Available Rides</title>
    <link rel="stylesheet" href="student.css">
    <style>
        .results-container { max-width: 800px; margin: 30px auto; padding: 20px; }
        .route-card-large { background: white; border-radius: 15px; padding: 20px; margin-bottom: 15px; display: flex; justify-content: space-between; align-items: center; box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
    </style>
</head>
<body>

    <?php include 'student-header.php'; ?>

    <div class="results-container">
        <h2><?= $p['location_name'] ?> ➔ <?= $d['location_name'] ?></h2>
        <p>Total Route Distance: <?= number_format($dist, 2) ?> km</p>
        <p style="color: #166534; font-size: 0.9rem;">🌱 Book this ride to earn <strong><?= $eco_points ?> Eco-Points</strong>!</p>
        <hr>

        <?php if(mysqli_num_rows($rides) > 0): ?>
            <?php while($ride = mysqli_fetch_assoc($rides)): 
                $r_id = $ride['ride_id'];
                $pax_res = mysqli_query($conn, "SELECT COUNT(*) as total FROM carpool_request_table WHERE ride_id = '$r_id' AND status = 'approved'");
                $pax = mysqli_fetch_assoc($pax_res)['total'];
                
                //Split fare logic (Total Fare / Number of Students)
                $price = $total_fare / ($pax + 1);
            ?>
                <div class="route-card-large">
                    <div>
                        <strong>Driver: <?= $ride['driver'] ?></strong><br>
                        <small>Already Joined: <?= $pax ?> Students</small><br>
                        <small style="color: #e11d48;">Seats Available: <?= $ride['total_seats'] ?></small>
                    </div>
                    <div style="text-align:right">
                        <div style="color:green; font-weight:bold; font-size:1.2rem;">RM <?= number_format($price, 2) ?></div>
                        <a href="request-ride.php?id=<?= $r_id ?>&fare=<?= $price ?>" class="btn student">Join Ride</a>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div style="text-align:center; padding: 20px; color: #64748b;">
                <p>No rides available for this route with open seats.</p>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>