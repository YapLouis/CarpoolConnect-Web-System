<?php
include 'db.php';
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'driver') {
    header("Location: login.php");
    exit();
}

if (!isset($_GET['ride_id'])) {
    header("Location: driver-my-rides.php");
    exit();
}

$ride_id = mysqli_real_escape_string($conn, $_GET['ride_id']);
$message = "";

//Fetch Ride and Coordinates
$rideInfo = mysqli_query($conn, "SELECT r.*, lp.location_name as pickup, lp.latitude as p_lat, lp.longitude as p_lng,
                                        ld.location_name as dropoff, ld.latitude as d_lat, ld.longitude as d_lng 
                                 FROM rides_table r 
                                 JOIN location_table lp ON r.pickup_id = lp.location_id 
                                 JOIN location_table ld ON r.dropoff_id = ld.location_id 
                                 WHERE r.ride_id = '$ride_id'");
$ride = mysqli_fetch_assoc($rideInfo);

//Find out exactly how far the car is traveling
$distance = getEstimatedRoadDist($ride['p_lat'], $ride['p_lng'], $ride['d_lat'], $ride['d_lng']);

//Set the "Official Price" based on that distance so everyone sees the same total
$totalVehicleCost = calculateTotalFare($distance);

//Handle Approval/Rejection
if (isset($_POST['update_status'])) {
    $req_id = mysqli_real_escape_string($conn, $_POST['request_id']);
    $new_status = mysqli_real_escape_string($conn, $_POST['status']); 

    $updateQuery = "UPDATE carpool_request_table SET status = '$new_status' WHERE request_id = '$req_id'";
    if (mysqli_query($conn, $updateQuery)) {
        if ($new_status === 'approved') {
            mysqli_query($conn, "UPDATE rides_table SET total_seats = total_seats - 1 WHERE ride_id = '$ride_id' AND total_seats > 0");
        }
        $message = "<div style='padding:15px; background:#dcfce7; color:#166534; border-radius:8px; margin: 20px;'>Status updated! Fares synchronized.</div>";
    }
}

//Update the database to match for everyone currently approved
$countRes = mysqli_query($conn, "SELECT COUNT(*) as total FROM carpool_request_table WHERE ride_id = '$ride_id' AND status = 'approved'");
$countData = mysqli_fetch_assoc($countRes);
$approvedCount = $countData['total'];

if ($approvedCount > 0) {
    $currentSplitFare = $totalVehicleCost / $approvedCount;
    mysqli_query($conn, "UPDATE carpool_request_table SET fare = '$currentSplitFare' WHERE ride_id = '$ride_id' AND status = 'approved'");
} else {
    $currentSplitFare = $totalVehicleCost; 
}

//Fetch All Student Requests
$requestsRes = mysqli_query($conn, "SELECT cr.*, u.full_name, u.phone_number 
                                    FROM carpool_request_table cr
                                    JOIN user_table u ON cr.student_id = u.user_id
                                    WHERE cr.ride_id = '$ride_id'");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Requests - APU Carpool</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="driver.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body style="background: white !important; margin: 0; font-family: sans-serif;">

    <?php include 'driver-header.php'; ?>

    <div class="dashboard-container" style="max-width: 1000px; margin: 20px auto; padding: 20px;">
        <div style="margin-bottom: 30px;">
            <a href="driver-my-rides.php" style="text-decoration: none; color: #64748b;"><i class="fas fa-arrow-left"></i> Back to My Rides</a>
            <h1 style="color: #1e293b; margin-top: 15px;">Requests for Ride #<?= $ride_id ?></h1>
            
            <div style="background: white; padding: 20px; border-radius: 12px; border: 1px solid #e2e8f0; margin-top: 15px;">
                <p style="margin: 0; color: #1e293b; font-weight: bold; font-size: 1.1rem;">
                    <?= $ride['pickup'] ?> <i class="fas fa-arrow-right" style="font-size: 0.8rem; margin: 0 10px;"></i> <?= $ride['dropoff'] ?>
                </p>
                <div style="display: flex; gap: 20px; margin-top: 10px; flex-wrap: wrap;">
                    <span style="color: #64748b;"><i class="far fa-clock"></i> <?= date('d M, h:i A', strtotime($ride['departure_time'])) ?></span>
                    <span style="color: #166534; font-weight: 600;"><i class="fas fa-money-bill-wave"></i> Total: RM <?= number_format($totalVehicleCost, 2) ?></span>
                    <span style="color: #0369a1; font-weight: 600;"><i class="fas fa-users"></i> Split Fare: RM <?= number_format($currentSplitFare, 2) ?> (<?= $approvedCount ?> Approved)</span>
                    <span style="color: #e11d48; font-weight: 600;"><i class="fas fa-chair"></i> Seats Left: <?= $ride['total_seats'] ?></span>
                </div>
            </div>
        </div>

        <?= $message ?>

        <div style="background: white; padding: 20px; border-radius: 12px; box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1);">
            <?php if(mysqli_num_rows($requestsRes) > 0): ?>
                <table style="width: 100%; border-collapse: collapse;">
                    <thead>
                        <tr style="text-align: left; border-bottom: 2px solid #f1f5f9; color: #64748b; font-size: 0.9rem;">
                            <th style="padding: 15px;">Student Name</th>
                            <th style="padding: 15px;">Current Fare (RM)</th>
                            <th style="padding: 15px;">Status</th>
                            <th style="padding: 15px; text-align: right;">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($req = mysqli_fetch_assoc($requestsRes)): ?>
                            <tr style="border-bottom: 1px solid #f1f5f9;">
                                <td style="padding: 15px;">
                                    <strong style="color: #1e293b;"><?= htmlspecialchars($req['full_name']) ?></strong><br>
                                    <small style="color: #0ea5e9;"><?= $req['phone_number'] ?></small>
                                </td>
                                <td style="padding: 15px;">
                                    <?php if($req['status'] == 'approved'): ?>
                                        <strong style="color: #166534;">RM <?= number_format($req['fare'], 2) ?></strong>
                                    <?php else: ?>
                                        <span style="color: #94a3b8; font-size: 0.85rem;">Pending approval</span>
                                    <?php endif; ?>
                                </td>
                                <td style="padding: 15px;">
                                    <?php 
                                        $status = $req['status'];
                                        $bStyle = "padding: 5px 12px; border-radius: 20px; font-size: 0.75rem; font-weight: bold; text-transform: uppercase;";
                                        if($status == 'approved') $bStyle .= "background:#dcfce7; color:#166534;";
                                        elseif($status == 'rejected') $bStyle .= "background:#fee2e2; color:#991b1b;";
                                        else $bStyle .= "background:#fef9c3; color:#854d0e;";
                                    ?>
                                    <span style="<?= $bStyle ?>"><?= $status ?></span>
                                </td>
                                <td style="padding: 15px; text-align: right;">
                                    <?php if($req['status'] == 'pending'): ?>
                                        <form method="POST" style="display: inline-block;">
                                            <input type="hidden" name="request_id" value="<?= $req['request_id'] ?>">
                                            <input type="hidden" name="status" id="status_input_<?= $req['request_id'] ?>" value="">
                                            <button type="submit" name="update_status" 
                                                    onclick="document.getElementById('status_input_<?= $req['request_id'] ?>').value='approved'" 
                                                    style="background: #22c55e; color: white; border: none; padding: 8px 15px; border-radius: 6px; cursor: pointer; font-weight: bold; margin-right: 5px;">
                                                Approve
                                            </button>
                                            <button type="submit" name="update_status" 
                                                    onclick="document.getElementById('status_input_<?= $req['request_id'] ?>').value='rejected'" 
                                                    style="background: #ef4444; color: white; border: none; padding: 8px 15px; border-radius: 6px; cursor: pointer; font-weight: bold;">
                                                Reject
                                            </button>
                                        </form>
                                    <?php else: ?>
                                        <span style="color: #cbd5e1; font-size: 0.85rem; font-style: italic;">No actions</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div style="text-align: center; padding: 40px; color: #94a3b8;">
                    <p>No student requests yet for this ride.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>