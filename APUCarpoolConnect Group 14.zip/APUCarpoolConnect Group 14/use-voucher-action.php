<?php
include 'db.php';
session_start();

if (isset($_POST['redemption_id'])) {
    $r_id = $_POST['redemption_id'];
    
    //Update status to unavailable
    $update = "UPDATE voucher_redemption_table SET redemption_status = 'unavailable' WHERE redemption_id = '$r_id'";
    
    if (mysqli_query($conn, $update)) {
        //Redirect back to the dashboard
        header("Location: carbon-reward.php?used_success=1");
        exit();
    }
}
?>