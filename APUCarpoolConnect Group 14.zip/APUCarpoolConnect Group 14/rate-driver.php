<?php
include 'db.php';
session_start();

//Get IDs from either GET (initial load) or POST (form submission)
$ride_id = isset($_GET['ride_id']) ? mysqli_real_escape_string($conn, $_GET['ride_id']) : (isset($_POST['ride_id']) ? mysqli_real_escape_string($conn, $_POST['ride_id']) : '');
$driver_id = isset($_GET['driver_id']) ? mysqli_real_escape_string($conn, $_GET['driver_id']) : (isset($_POST['driver_id']) ? mysqli_real_escape_string($conn, $_POST['driver_id']) : '');
$student_id = $_SESSION['user_id'];

//Security Check
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'student' || empty($ride_id)) {
    header("Location: ride-history.php");
    exit();
}

if (isset($_POST['submit_rating'])) {
    $score = intval($_POST['rating_score']);

    //New ID Generation
    //Default if table is empty
    $idRes = mysqli_query($conn, "SELECT rating_id FROM ratings_table ORDER BY rating_id DESC LIMIT 1");
    $newID = "RT001"; 
    
    if (mysqli_num_rows($idRes) > 0) {
        $lastID = mysqli_fetch_assoc($idRes)['rating_id'];
        //Extract number from "RT001", increment it, and pad back to 3 digits
        $num = (int)substr($lastID, 2) + 1;
        $newID = "RT" . str_pad($num, 3, "0", STR_PAD_LEFT);
    }

    //Insert the new rating with the generated ID
    $insert = "INSERT INTO ratings_table (rating_id, ride_id, student_id, driver_id, rating_score) 
               VALUES ('$newID', '$ride_id', '$student_id', '$driver_id', '$score')";
    
    if (mysqli_query($conn, $insert)) {
        //Calculate the NEW AVERAGE for this driver
        $avgQuery = "SELECT AVG(rating_score) as avg_score FROM ratings_table WHERE driver_id = '$driver_id'";
        $avgRes = mysqli_query($conn, $avgQuery);
        $avgRow = mysqli_fetch_assoc($avgRes);
        $newAverage = $avgRow['avg_score'];

        //Update driver_detail_table with the fresh average
        $updateDriver = "UPDATE driver_detail_table SET driver_rating = '$newAverage' WHERE driver_id = '$driver_id'";
        mysqli_query($conn, $updateDriver);

        header("Location: ride-history.php?status=success");
        exit();
    } else {
        die("Error: " . mysqli_error($conn));
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="student.css">
    <title>Rate Your Ride</title>
</head>
<body>
    <?php include 'student-header.php'; ?>

    <div style="max-width: 400px; margin: 100px auto; text-align: center; background: white; padding: 30px; border-radius: 15px; box-shadow: 0 4px 10px rgba(0,0,0,0.1);">
        <h2>How was your ride?</h2>
        <form method="POST">
            <input type="hidden" name="ride_id" value="<?= htmlspecialchars($ride_id) ?>">
            <input type="hidden" name="driver_id" value="<?= htmlspecialchars($driver_id) ?>">
            
            <div style="margin: 20px 0;">
                <select name="rating_score" style="padding: 10px; width: 100%; border-radius: 8px; border: 1px solid #ddd;" required>
                    <option value="" disabled selected>Select a rating</option>
                    <option value="5">⭐⭐⭐⭐⭐ (Excellent)</option>
                    <option value="4">⭐⭐⭐⭐ (Good)</option>
                    <option value="3">⭐⭐⭐ (Average)</option>
                    <option value="2">⭐⭐ (Poor)</option>
                    <option value="1">⭐ (Terrible)</option>
                </select>
            </div>
            
            <button type="submit" name="submit_rating" class="btn student" style="width: 100%; padding: 12px; cursor: pointer;">Submit Feedback</button>
            <br><br>
            <a href="ride-history.php" style="color: #666; text-decoration: none; font-size: 0.9rem;">Not now</a>
        </form>
    </div>
</body>
</html>