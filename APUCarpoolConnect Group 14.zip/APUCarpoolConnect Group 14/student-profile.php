<?php
include 'db.php';
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'student') {
    header("Location: login.php"); exit();
}

$student_id = $_SESSION['user_id'];
$message = "";

//PROFILE UPDATE
if (isset($_POST['update_profile'])) {
    $fullname = mysqli_real_escape_string($conn, $_POST['full_name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone_number']);
    $emergency = mysqli_real_escape_string($conn, $_POST['emergency_contact']);
    $new_password = $_POST['new_password'];

    mysqli_begin_transaction($conn);

    try {
        //Update user_table
        $updateUser = "UPDATE user_table SET 
                       full_name = '$fullname', 
                       email = '$email', 
                       phone_number = '$phone' 
                       WHERE user_id = '$student_id'";
        mysqli_query($conn, $updateUser);

        //Update student_details_table
        $updateStudent = "UPDATE student_details_table SET 
                          emergency_contact = '$emergency' 
                          WHERE student_id = '$student_id'";
        mysqli_query($conn, $updateStudent);

        //Update password if provided
        if (!empty($new_password)) {
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            $hashed_password = mysqli_real_escape_string($conn, $hashed_password);
            mysqli_query($conn, "UPDATE user_table SET password = '$hashed_password' WHERE user_id = '$student_id'");
        }

        mysqli_commit($conn);
        
        //prevent "Confirm Form Resubmission"
        header("Location: student-profile.php?status=success");
        exit();
    } catch (Exception $e) {
        mysqli_rollback($conn);
        header("Location: student-profile.php?status=error");
        exit();
    }
}

//Handle status messages
if (isset($_GET['status'])) {
    if ($_GET['status'] == 'success') {
        $message = "<div class='alert success'>Profile updated successfully!</div>";
    } else {
        $message = "<div class='alert error'>Update failed. Please try again.</div>";
    }
}

//Fetch current data
$query = "SELECT u.*, s.tp_number, s.emergency_contact, s.total_points 
          FROM user_table u 
          JOIN student_details_table s ON u.user_id = s.student_id 
          WHERE u.user_id = '$student_id'";
$res = mysqli_query($conn, $query);
$user = mysqli_fetch_assoc($res);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile - APU Carpool</title>
    <link rel="stylesheet" href="student.css">
    <style>
        .profile-container { max-width: 600px; margin: 40px auto; background: white; padding: 30px; border-radius: 15px; box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
        .form-group { margin-bottom: 20px; }
        .form-group label { display: block; margin-bottom: 5px; font-weight: bold; color: #555; }
        .form-group input { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 8px; font-size: 1rem; box-sizing: border-box; transition: 0.3s; }
        
        .form-group input:disabled { background: #f4f4f4; color: #777; cursor: not-allowed; border-color: #eee; }
        .form-group input[readonly] { background: #f9f9f9; color: #888; cursor: not-allowed; }
        
        .btn-group { display: flex; gap: 10px; margin-top: 20px; }
        
        /*button style*/
        .btn-toggle, .btn-save, .btn-logout { 
            flex: 1; 
            padding: 12px 25px; 
            border-radius: 8px; 
            cursor: pointer; 
            font-size: 1rem; 
            transition: 0.3s; 
            border: none; 
            text-align: center;
            text-decoration: none;
            font-weight: bold;
        }

        .btn-toggle { background: #3498db; color: white; }
        .btn-save { background: #27ae60; color: white; display: none; }
        
        /*Logout Button*/
        .btn-logout { background: #e74c3c; color: white; }
        .btn-logout:hover { background: #c0392b; }

        .alert { padding: 15px; border-radius: 8px; margin-bottom: 20px; text-align: center; }
        .success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .error { background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
        .points-badge { display: inline-block; background: #e8f5e9; color: #2e7d32; padding: 5px 15px; border-radius: 20px; font-size: 0.9rem; margin-top: 5px; }
    </style>
</head>
<body>
    <?php include 'student-header.php'; ?>

    <div class="profile-container">
        <h2 style="margin:0; color: #333;">👤 My Profile</h2>
        
        <?= $message ?>

        <form id="profileForm" method="POST" action="">
            <div style="display: flex; gap: 15px;">
                <div class="form-group" style="flex: 1;">
                    <label>Student ID</label>
                    <input type="text" value="<?= $user['user_id'] ?>" readonly>
                </div>
                <div class="form-group" style="flex: 1;">
                    <label>TP Number</label>
                    <input type="text" value="<?= $user['tp_number'] ?>" readonly>
                </div>
            </div>

            <div class="form-group">
                <label>Current Eco Points</label>
                <div class="points-badge">🌱 <?= number_format($user['total_points']) ?> Points Earned</div>
            </div>

            <hr style="border:0; border-top:1px solid #eee; margin: 20px 0;">

            <div class="form-group">
                <label>Full Name</label>
                <input type="text" name="full_name" class="editable" value="<?= htmlspecialchars($user['full_name']) ?>" required disabled>
            </div>

            <div class="form-group">
                <label>Email Address</label>
                <input type="email" name="email" class="editable" value="<?= htmlspecialchars($user['email']) ?>" required disabled>
            </div>

            <div class="form-group">
                <label>Phone Number</label>
                <input type="text" name="phone_number" class="editable" value="<?= htmlspecialchars($user['phone_number']) ?>" required disabled>
            </div>

            <div class="form-group">
                <label>Emergency Contact</label>
                <input type="text" name="emergency_contact" class="editable" value="<?= htmlspecialchars($user['emergency_contact']) ?>" required disabled>
            </div>

            <div class="form-group">
                <label>New Password (Leave blank to keep current)</label>
                <input type="password" name="new_password" class="editable" placeholder="••••••••" disabled>
            </div>

            <div class="btn-group">
                <button type="button" id="toggleBtn" class="btn-toggle" onclick="toggleEdit()">✏️ Edit Profile</button>
                <button type="submit" name="update_profile" id="saveBtn" class="btn-save">💾 Save Changes</button>
                <a href="login.php" class="btn-logout" onclick="return confirm('Are you sure you want to logout?')">🚪 Logout</a>
            </div>
        </form>
    </div>

    <script>
    let isEditing = false;

    function toggleEdit() {
        isEditing = !isEditing; 
        
        const inputs = document.querySelectorAll('.editable');
        const toggleBtn = document.getElementById('toggleBtn');
        const saveBtn = document.getElementById('saveBtn');

        if (isEditing) {
            inputs.forEach(input => {
                input.disabled = false;
            });
            toggleBtn.innerHTML = "✖ Cancel";
            toggleBtn.style.background = "#e74c3c";
            saveBtn.style.display = "block";
            inputs[0].focus(); 
        } else {    
            inputs.forEach(input => {
                input.value = input.defaultValue;
                input.disabled = true;
            });
            toggleBtn.innerHTML = "✏️ Edit Profile";
            toggleBtn.style.background = "#3498db";
            saveBtn.style.display = "none";
        }
    }
    </script>
</body>
</html>