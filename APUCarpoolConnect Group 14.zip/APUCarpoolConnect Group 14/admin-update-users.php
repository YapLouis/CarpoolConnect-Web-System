<?php
include 'db.php';
header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);

if (!$data) {
    echo json_encode(['success' => false, 'message' => 'No data received']);
    exit;
}

$uid = mysqli_real_escape_string($conn, $data['user_id']);
$name = mysqli_real_escape_string($conn, $data['full_name']);
$email = mysqli_real_escape_string($conn, $data['email']);
$phone = mysqli_real_escape_string($conn, $data['phone_number']);

//Update user_table
$update_user = "UPDATE user_table SET full_name='$name', email='$email', phone_number='$phone' WHERE user_id='$uid'";

if (mysqli_query($conn, $update_user)) {
    
    //Update specific detail tables based on role
    if ($data['user_type'] === 'student') {
        $tp = mysqli_real_escape_string($conn, $data['tp_number']);
        $ec = mysqli_real_escape_string($conn, $data['emergency_contact']);
        $update_details = "UPDATE student_details_table SET tp_number='$tp', emergency_contact='$ec' WHERE student_id='$uid'";
        
        if (!mysqli_query($conn, $update_details)) {
            echo json_encode(['success' => false, 'message' => 'Student detail update failed']);
            exit;
        }
    } 
    elseif ($data['user_type'] === 'driver') {
        $ln = mysqli_real_escape_string($conn, $data['license_number']);
        $cm = mysqli_real_escape_string($conn, $data['car_model']);
        $pn = mysqli_real_escape_string($conn, $data['plate_number']);
        $rt = mysqli_real_escape_string($conn, $data['driver_rating']); 
        
        $update_details = "UPDATE driver_detail_table SET license_number='$ln', car_model='$cm', plate_number='$pn', driver_rating='$rt' WHERE driver_id='$uid'";
        
        if (!mysqli_query($conn, $update_details)) {
            echo json_encode(['success' => false, 'message' => 'Driver detail update failed']);
            exit;
        }
    }
    //If user_type is admin, don't need to have second query
    
    echo json_encode(['success' => true]);

} else {
    echo json_encode(['success' => false, 'message' => 'User table update failed']);
}
?>