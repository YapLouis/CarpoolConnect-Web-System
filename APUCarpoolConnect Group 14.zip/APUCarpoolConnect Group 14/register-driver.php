<?php
    include 'db.php';
    session_start();

    //When btnRegister was clicked
    if(isset($_POST['btnRegister'])){
        $fullname = $_POST['full_name'];
        $email = $_POST['email'];
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $phone_number = $_POST['phone_number'];
        $license_number = $_POST['license_number'];
        $car_model = $_POST['car_model'];
        $plate_number = $_POST['plate_number'];

        //Auto Increment (US001,US002...)
        $idQuery = "SELECT user_id FROM user_table ORDER BY user_id DESC LIMIT 1";
        $idResult = mysqli_query($conn, $idQuery);
        
        if (mysqli_num_rows(result: $idResult) > 0) {
            $last_user = mysqli_fetch_assoc(result: $idResult);
            $last_number = (int)substr($last_user['user_id'], 2);
            $new_number = $last_number + 1;
        } else {
            $new_number = 1;
        }
        $user_id = "US" . str_pad($new_number, 3, "0", STR_PAD_LEFT);

        //Insert into user_table
        $query1 = "INSERT INTO user_table (user_id, full_name, email, password, phone_number, role) 
                   VALUES ('$user_id', '$fullname', '$email', '$password', '$phone_number', 'driver')";
        
        $result1 = mysqli_query($conn, $query1);

        //Insert into driver_detail_table
        $query2 = "INSERT INTO driver_detail_table (driver_id, license_number, car_model, plate_number, driver_rating) 
                   VALUES ('$user_id', '$license_number', '$car_model', '$plate_number', 0.00)";
        
        $result2 = mysqli_query($conn, $query2);

        //Check if both queries were successful
        if($result1 && $result2){
            echo "<script>alert('Driver Registered Successfully!'); window.location.href='index.html';</script>";
        } else {
            //Show the specific error if it fails
            $error = mysqli_error($conn);
            echo "<script>alert('Registration failed: $error');</script>";
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Driver Registration - APU Carpool</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="scroll-body">

    <div class="container registration-box">
        <img src="apucarpoolconnectlogo.png" alt="APU Carpool Logo" class="app-logo">
        
        <h1>DRIVER REGISTER</h1>
        <p>Complete your profile to start providing rides</p>

        <form class="form-group" method="POST" action="register-driver.php">
            
            <input type="text" name="full_name" placeholder="Full Name" required>
            <input type="email" name="email" placeholder="APU Student Email" required>
            <input type="password" name="password" placeholder="Create Password" required>
            <input type="tel" name="phone_number" placeholder="Phone Number (e.g., 012-3456789)" required>
            <input type="text" name="license_number" placeholder="Driving License Number" required>
            <input type="text" name="car_model" placeholder="Car Model (e.g., Perodua Myvi)" required>
            <input type="text" name="plate_number" placeholder="Plate Number (e.g., VGH 1234)" required>

            <div class="button-group">
                <a href="index.html" class="btn driver">Back</a>
                <button type="submit" name="btnRegister" class="btn student">Register Driver</button>
            </div>
        </form>
    </div>
</body>
</html>