<?php
include 'db.php';
include 'admin-header.php';

//HANDLE DELETE VOUCHER
if(isset($_GET['delete_v_id'])){
    $id = mysqli_real_escape_string($conn, $_GET['delete_v_id']);
    mysqli_query($conn, "DELETE FROM voucher_list_table WHERE voucher_id = '$id'");
    header("Location: admin-rewards.php");
    exit();
}

//FETCH VOUCHERS
$vouchers = mysqli_query($conn, "SELECT * FROM voucher_list_table ORDER BY voucher_name ASC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rewards Management - APU Carpool</title>
    <link rel="stylesheet" href="admin-style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body style="overflow: auto;">

<div class="main-content" style="display: block; padding-top: 100px;">
    <div class="content-wrapper" style="margin: auto; max-width: 98%;">
        
        <div style="margin-bottom: 30px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 20px;">
            <div>
                <h1 style="color: #003366; text-transform: uppercase; margin: 0;">Reward Management</h1>
                <p style="color: #888; margin: 5px 0 0; font-size: 0.85rem;">Manage student redemption vouchers, point costs, and inventory stock</p>
            </div>
            
            <a href="admin-add-rewards.php" class="btn-add">
                <i class="fas fa-gift"></i> Create New Voucher
            </a>
        </div>

        <div class="table-container" style="overflow-x: auto;">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>Voucher ID</th>
                        <th>Voucher Name</th>
                        <th>Point Cost</th>
                        <th>Stock</th>
                        <th>Terms & Conditions</th>
                        <th>Status</th>
                        <th style="text-align: center;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($row = mysqli_fetch_assoc($vouchers)): ?>
                    <tr id="v-row-<?= $row['voucher_id'] ?>">
                        <td><code><?= $row['voucher_id'] ?></code></td>
                        <td>
                            <input type="text" name="voucher_name" class="inline-input" 
                                value="<?= $row['voucher_name'] ?>" readonly 
                                oninput="vChanged('<?= $row['voucher_id'] ?>')" style="font-weight: bold;">
                        </td>
                        <td>
                            <input type="number" name="point_cost" class="inline-input" 
                                value="<?= $row['point_cost'] ?>" readonly 
                                oninput="vChanged('<?= $row['voucher_id'] ?>')">
                        </td>
                        <td>
                            <input type="number" name="stock_quantity" class="inline-input" 
                                value="<?= $row['stock_quantity'] ?>" readonly 
                                oninput="vChanged('<?= $row['voucher_id'] ?>')">
                        </td>
                        <td style="min-width: 250px;">
                            <textarea name="terms_conditions" class="inline-input" readonly 
                                style="resize: none; overflow: hidden; height: auto; min-height: 20px; font-size: 0.8rem; background: transparent; border: none; width: 100%; display: block;"
                                oninput="vChanged('<?= $row['voucher_id'] ?>'); this.style.height = ''; this.style.height = this.scrollHeight + 'px';"><?= htmlspecialchars($row['terms_conditions']) ?></textarea>
                        </td>
                        <td>
                            <select name="voucher_status" class="inline-input" onchange="updateVoucherStatus('<?= $row['voucher_id'] ?>', this.value)">
                                <option value="1" <?= $row['voucher_status'] == 1 ? 'selected' : '' ?>>Active</option>
                                <option value="0" <?= $row['voucher_status'] == 0 ? 'selected' : '' ?>>Inactive</option>
                            </select>
                        </td>
                        <td style="text-align: center; white-space: nowrap;">
                            <button class="btn-action btn-edit" id="btn-edit-v-<?= $row['voucher_id'] ?>" onclick="enableVRow('<?= $row['voucher_id'] ?>')">
                                <i class="fas fa-edit"></i>
                            </button>
                            
                            <button class="btn-action btn-confirm" id="btn-save-v-<?= $row['voucher_id'] ?>" style="display:none;" onclick="updateVoucherData('<?= $row['voucher_id'] ?>')">
                                <i class="fas fa-check"></i>
                            </button>

                            <a href="admin-rewards.php?delete_v_id=<?= $row['voucher_id'] ?>" class="btn-action btn-delete" onclick="return confirm('Delete this reward?')">
                                <i class="fas fa-trash-alt"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
window.addEventListener('load', () => {
    document.querySelectorAll('textarea[name="terms_conditions"]').forEach(el => {
        el.style.height = el.scrollHeight + 'px';
    });
});

function enableVRow(id) {
    const row = document.getElementById('v-row-' + id);
    const fields = row.querySelectorAll('input, textarea');
    const saveBtn = document.getElementById('btn-save-v-' + id);
    const editBtn = document.getElementById('btn-edit-v-' + id);
    
    //Check if currently in read-only mode
    const isCurrentlyReadOnly = fields[0].readOnly;

    if (isCurrentlyReadOnly) {
        //Toggle ON: Show edit fields
        fields.forEach(field => {
            field.readOnly = false;
            field.style.background = "#fff";
            field.style.border = "1px solid #ddd";
        });
        fields[0].focus();
    } else {
        //Toggle OFF: Hide edit fields
        fields.forEach(field => {
            field.readOnly = true;
            field.style.background = "transparent";
            field.style.border = "none";
        });
        saveBtn.style.display = 'none';
        editBtn.style.display = 'inline-flex';
    }
}

function vChanged(id) {
    document.getElementById('btn-edit-v-' + id).style.display = 'none';
    document.getElementById('btn-save-v-' + id).style.display = 'inline-flex';
}

function updateVoucherData(id) {
    const row = document.getElementById('v-row-' + id);
    const fields = row.querySelectorAll('input, select, textarea');
    let formData = { voucher_id: id };
    fields.forEach(field => formData[field.name] = field.value);

    fetch('admin-update-rewards.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
    })
    .then(r => r.json())
    .then(data => {
        if(data.success) { 
            alert("Reward details updated successfully!"); 
            location.reload(); 
        } else { 
            alert("Error: " + data.message); 
        }
    });
}

function updateVoucherStatus(id, status) {
    fetch('admin-update-rewards.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ voucher_id: id, voucher_status: status })
    })
    .then(r => r.json())
    .then(data => {
        if(data.success) { 
            alert("Voucher status updated successfully!"); 
        } else { 
            alert("Error updating status: " + data.message); 
            location.reload(); 
        }
    });
}
</script>

</body>
</html>