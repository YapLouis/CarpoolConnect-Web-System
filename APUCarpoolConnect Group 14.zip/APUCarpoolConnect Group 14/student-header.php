<header class="student-header">
    <div class="logo-container">
        <a href="student-homepage.php">
            <img src="apucarpoolconnectlogo-header.png" alt="APU Carpool Logo" class="header-logo">
        </a>
    </div>
    <nav class="nav-links">
        <a href="student-homepage.php">Home</a>
        <a href="carbon-reward.php">Carbon Saving/Reward</a>
        <a href="ride-history.php">History</a>
        <a href="student-profile.php" style="color: #ff4d4d;">PROFILE</a>
    </nav>
</header>