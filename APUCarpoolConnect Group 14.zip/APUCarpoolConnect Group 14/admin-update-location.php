<?php
include 'db.php';
header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);

if (isset($data['location_id'])) {
    $id = mysqli_real_escape_string($conn, $data['location_id']);
    $name = mysqli_real_escape_string($conn, $data['location_name']);
    $lat = mysqli_real_escape_string($conn, $data['latitude']);
    $lng = mysqli_real_escape_string($conn, $data['longitude']);

    $sql = "UPDATE location_table SET 
            location_name = '$name', 
            latitude = '$lat', 
            longitude = '$lng' 
            WHERE location_id = '$id'";

    if (mysqli_query($conn, $sql)) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => mysqli_error($conn)]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid data']);
}
?>