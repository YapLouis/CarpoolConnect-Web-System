<?php
include 'db.php';
header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);

if (isset($data['voucher_id'])) {
    $id = mysqli_real_escape_string($conn, $data['voucher_id']);
    
    $updates = [];
    if(isset($data['voucher_name'])) $updates[] = "voucher_name = '" . mysqli_real_escape_string($conn, $data['voucher_name']) . "'";
    if(isset($data['point_cost'])) $updates[] = "point_cost = " . (int)$data['point_cost'];
    if(isset($data['stock_quantity'])) $updates[] = "stock_quantity = " . (int)$data['stock_quantity'];
    if(isset($data['voucher_status'])) $updates[] = "voucher_status = " . (int)$data['voucher_status'];
    if(isset($data['terms_conditions'])) $updates[] = "terms_conditions = '" . mysqli_real_escape_string($conn, $data['terms_conditions']) . "'";

    if(empty($updates)) {
        echo json_encode(['success' => false, 'message' => 'No fields to update']);
        exit;
    }

    $sql = "UPDATE voucher_list_table SET " . implode(', ', $updates) . " WHERE voucher_id = '$id'";

    if (mysqli_query($conn, $sql)) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => mysqli_error($conn)]);
    }
}
?>