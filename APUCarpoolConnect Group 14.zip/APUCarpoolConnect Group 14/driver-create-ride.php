<?php
include 'db.php';
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'driver') {
    header("Location: login.php");
    exit();
}

$driver_id = $_SESSION['user_id'];
$message = "";

$locationsResult = mysqli_query($conn, "SELECT * FROM location_table ORDER BY location_name ASC");
$locationsArray = mysqli_fetch_all($locationsResult, MYSQLI_ASSOC);

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['btnPostRide'])) {
    $pickup_id = mysqli_real_escape_string($conn, $_POST['pickup_id']);
    $dropoff_id = mysqli_real_escape_string($conn, $_POST['dropoff_id']);
    $departure_time = mysqli_real_escape_string($conn, $_POST['departure_time']);
    $total_seats = (int)$_POST['total_seats'];

    if ($pickup_id == $dropoff_id) {
        $message = "<div style='color:red; background:#fee2e2; padding:10px; border-radius:5px; margin-bottom:15px;'>Pickup and Destination cannot be the same!</div>";
    } else {
        $idRes = mysqli_query($conn, "SELECT ride_id FROM rides_table ORDER BY ride_id DESC LIMIT 1");
        $newID = "R001"; 
        if (mysqli_num_rows($idRes) > 0) {
            $lastID = mysqli_fetch_assoc($idRes)['ride_id'];
            $num = (int)substr($lastID, 2) + 1;
            $newID = "R" . str_pad($num, 3, "0", STR_PAD_LEFT);
        }

        $insertQuery = "INSERT INTO rides_table (ride_id, driver_id, pickup_id, dropoff_id, departure_time, total_seats, ride_status) 
                        VALUES ('$newID', '$driver_id', '$pickup_id', '$dropoff_id', '$departure_time', '$total_seats', 'active')";

        if (mysqli_query($conn, $insertQuery)) {
            echo "<script>alert('Ride Published!'); window.location.href='driver-homepage.php';</script>";
            exit();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Post Ride - APU Carpool</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="driver.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body style="background: white !important; margin: 0;">
    
    <?php include 'driver-header.php'; ?>

    <div class="dashboard-container">
        <h1 style="margin-bottom: 25px; color: #1e293b;">Publish New Ride</h1>

        <div style="display: flex; gap: 20px;">
            <div style="flex: 1; background: white; padding: 30px; border-radius: 15px; box-shadow: 0 4px 15px rgba(0,0,0,0.05);">
                <?= $message ?>
                <form method="POST" action="driver-create-ride.php">
                    <label style="font-weight: bold; color: #64748b;">Pickup Location</label>
                    <select name="pickup_id" id="pickup_select" onchange="updateMarkers()" required style="width:100%; padding:10px; margin: 10px 0 20px; border-radius: 8px; border: 1px solid #ddd;">
                        <option value="">Select Pickup</option>
                        <?php foreach($locationsArray as $loc): ?>
                            <option value="<?= $loc['location_id'] ?>" data-lat="<?= $loc['latitude'] ?>" data-lng="<?= $loc['longitude'] ?>">
                                <?= $loc['location_name'] ?>
                            </option>
                        <?php endforeach; ?>
                    </select>

                    <label style="font-weight: bold; color: #64748b;">Destination</label>
                    <select name="dropoff_id" id="dropoff_select" onchange="updateMarkers()" required style="width:100%; padding:10px; margin: 10px 0 20px; border-radius: 8px; border: 1px solid #ddd;">
                        <option value="">Select Destination</option>
                        <?php foreach($locationsArray as $loc): ?>
                            <option value="<?= $loc['location_id'] ?>" data-lat="<?= $loc['latitude'] ?>" data-lng="<?= $loc['longitude'] ?>">
                                <?= $loc['location_name'] ?>
                            </option>
                        <?php endforeach; ?>
                    </select>

                    <label style="font-weight: bold; color: #64748b;">Departure Time</label>
                    <input type="datetime-local" name="departure_time" required style="width:100%; padding:10px; margin: 10px 0 20px; border-radius: 8px; border: 1px solid #ddd;">

                    <label style="font-weight: bold; color: #64748b;">Seats</label>
                    <input type="number" name="total_seats" min="1" max="4" value="4" required style="width:100%; padding:10px; margin: 10px 0 25px; border-radius: 8px; border: 1px solid #ddd;">

                    <button type="submit" name="btnPostRide" style="width: 100%; background: #1e293b; color: white; padding: 15px; border: none; border-radius: 8px; font-weight: bold; cursor: pointer;">
                        PUBLISH RIDE
                    </button>
                </form>
            </div>
            <div style="flex: 1.2;"><div id="map" style="height: 500px; border-radius: 15px; border: 5px solid white; box-shadow: 0 4px 15px rgba(0,0,0,0.05);"></div></div>
        </div>
    </div>

    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <script>
        var map = L.map('map').setView([3.0487, 101.6944], 14);
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(map);
        var pickupMarker, dropoffMarker;
        function updateMarkers() {
            const p = document.getElementById('pickup_select').selectedOptions[0];
            const d = document.getElementById('dropoff_select').selectedOptions[0];
            if (p.value) {
                if (pickupMarker) map.removeLayer(pickupMarker);
                pickupMarker = L.marker([p.dataset.lat, p.dataset.lng]).addTo(map).bindPopup("Pickup");
            }
            if (d.value) {
                if (dropoffMarker) map.removeLayer(dropoffMarker);
                dropoffMarker = L.marker([d.dataset.lat, d.dataset.lng]).addTo(map).bindPopup("Dropoff");
            }
            if (p.value && d.value) {
                var group = new L.featureGroup([pickupMarker, dropoffMarker]);
                map.fitBounds(group.getBounds().pad(0.3));
            }
        }
    </script>
</body>
</html>