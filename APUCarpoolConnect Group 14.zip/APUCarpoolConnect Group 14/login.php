<?php
    include 'db.php';
    session_start();

    if(isset($_POST['btnLogin'])){
        $email = mysqli_real_escape_string($conn, $_POST['email']);
        $password = $_POST['password']; 

        //Search for the user by email
        $query = "SELECT * FROM user_table WHERE email='$email'";
        $result = mysqli_query($conn, $query);

        if ($result && mysqli_num_rows($result) === 1){
            $row = mysqli_fetch_assoc($result); 
            
            //Verify the typed password against the hashed password in the DB
            if (password_verify($password, $row['password'])) {
                
                //Storing user data in session
                $_SESSION['user_id'] = $row['user_id'];
                $_SESSION['full_name'] = $row['full_name'];
                $_SESSION['role'] = $row['role'];

                $role = $row['role'];
                $redirect_page = "";

                if ($role === 'admin') {
                    $redirect_page = "admin-home.php";
                } else if ($role === 'student') {
                    $redirect_page = "student-homepage.php";
                } else if ($role === 'driver') {
                    $redirect_page = "driver-homepage.php";
                } else {
                    $redirect_page = "index.html";
                }

                //Redirecting using the determined page
                echo "<script>
                        alert('Login successful! Welcome " . $row['full_name'] . "'); 
                        window.location.href='$redirect_page';
                      </script>";
                exit();
            } else {
                //Password does not match hash
                echo "<script>
                        alert('Invalid email or password.'); 
                        window.location.href='login.php';
                      </script>";
                exit();
            }
        } else {
            //Email not found
            echo "<script>
                    alert('Invalid email or password.'); 
                    window.location.href='login.php';
                  </script>";
            exit();
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - APU Carpool</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="center-body">

    <div class="container registration-box">
        <img src="apucarpoolconnectlogo.png" alt="APU Carpool Logo" class="app-logo">
        
        <h1>LOGIN</h1>
        <p>Enter your credentials to access your account</p>

        <form class="form-group" method="POST" action="login.php">
    
            <input type="email" name="email" placeholder="APU Student Email" required>
            <input type="password" name="password" placeholder="Password" required>

            <div class="button-group">
                <a href="index.html" class="btn driver">Back</a>
                <button type="submit" name="btnLogin" class="btn login">Login</button>
            </div>
        </form>

        <p style="margin-top: 20px; font-size: 0.9rem;">
            Don't have an account? <br>
            <a href="register-student.php" style="color: #28a745; text-decoration: none; font-weight: bold;">Register as Student</a> | 
            <a href="register-driver.php" style="color: #333; text-decoration: none; font-weight: bold;">Register as Driver</a>
        </p>
    </div>
</body>
</html>