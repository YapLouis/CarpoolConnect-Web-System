<?php
include 'db.php';
session_start();

//Ensure the user is a student and the request is post
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_SESSION['user_id']) && $_SESSION['role'] === 'student') {
    $user_id = $_SESSION['user_id'];
    $voucher_id = mysqli_real_escape_string($conn, $_POST['voucher_id']);

    //Fetch Voucher Details (Cost and Stock)
    $vQuery = "SELECT point_cost, stock_quantity FROM voucher_list_table WHERE voucher_id = '$voucher_id'";
    $vResult = mysqli_query($conn, $vQuery);
    $vData = mysqli_fetch_assoc($vResult);

    //Fetch Student Points
    $pQuery = "SELECT total_points FROM student_details_table WHERE student_id = '$user_id'";
    $pResult = mysqli_query($conn, $pQuery);
    $pData = mysqli_fetch_assoc($pResult);

    //Validation: Check if student has enough points and voucher is in stock
    if ($pData['total_points'] >= $vData['point_cost'] && $vData['stock_quantity'] > 0) {
        
        //Generate a unique Redemption ID (e.g.,RD001)
        $idRes = mysqli_query($conn, "SELECT redemption_id FROM voucher_redemption_table ORDER BY redemption_id DESC LIMIT 1");
        $newID = "RD001";
        if (mysqli_num_rows($idRes) > 0) {
            $lastID = mysqli_fetch_assoc($idRes)['redemption_id'];
            $num = (int)substr($lastID, 2) + 1;
            $newID = "RD" . str_pad($num, 3, "0", STR_PAD_LEFT);
        }


        // Generates a code: APU-RD001-A2B3
        $randomSuffix = strtoupper(substr(md5(uniqid(mt_rand(), true)), 0, 4));
        $unique_code = "APU-" . $newID . "-" . $randomSuffix;

        //Database Transactions (Updates and Insert)
        //Deduct points from student
        mysqli_query($conn, "UPDATE student_details_table SET total_points = total_points - {$vData['point_cost']} WHERE student_id = '$user_id'");
        
        //Reduce voucher stock
        mysqli_query($conn, "UPDATE voucher_list_table SET stock_quantity = stock_quantity - 1 WHERE voucher_id = '$voucher_id'");

        //Record the redemption (Added unique_code to columns and values)
        $insertQuery = "INSERT INTO voucher_redemption_table (redemption_id, user_id, voucher_id, redemption_date, redemption_status, unique_code) 
                        VALUES ('$newID', '$user_id', '$voucher_id', CURRENT_TIMESTAMP, 'available', '$unique_code')";
        
        if (mysqli_query($conn, $insertQuery)) {
            //Redirect back to the rewards page
            header("Location: carbon-reward.php?redeem_success=1#my-vouchers");
            exit();
        } else {
            echo "Error: " . mysqli_error($conn);
        }
    } else {
        //Not enough points or no stock
        header("Location: carbon-reward.php?error=insufficient_funds");
        exit();
    }
} else {
    header("Location: login.php");
    exit();
}
?>