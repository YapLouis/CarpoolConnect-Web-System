<?php
include 'db.php';
include 'admin-header.php'; 

//Handle Delete
if(isset($_GET['delete_id'])){
    $id = mysqli_real_escape_string($conn, $_GET['delete_id']);
    
    //Prevent admin from deleting themselves
    if($id === $_SESSION['user_id']) {
        echo "<script>alert('Security Error: You cannot delete your own account while logged in.'); window.location.href='admin-users.php';</script>";
        exit();
    }

    mysqli_query($conn, "DELETE FROM user_table WHERE user_id = '$id'");
    header("Location: admin-users.php");
    exit();
}

//Fetch Data
$students = mysqli_query($conn, "SELECT u.*, s.tp_number, s.emergency_contact FROM user_table u 
    INNER JOIN student_details_table s ON u.user_id = s.student_id WHERE u.role = 'student' ORDER BY u.full_name ASC");

$drivers = mysqli_query($conn, "SELECT u.*, d.license_number, d.car_model, d.plate_number, d.driver_rating FROM user_table u 
    INNER JOIN driver_detail_table d ON u.user_id = d.driver_id WHERE u.role = 'driver' ORDER BY u.full_name ASC");

$admins = mysqli_query($conn, "SELECT * FROM user_table WHERE role = 'admin' ORDER BY full_name ASC");

$current_admin = $_SESSION['user_id'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Management - APU Carpool</title>
    <link rel="stylesheet" href="admin-style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body style="overflow: auto;">
    
    <div class="main-content" style="display: block; padding-top: 100px;">
        <div class="content-wrapper" style="margin: auto; max-width: 95%;"> 
            <div style="margin-bottom: 30px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 20px;">
                <div>
                    <h1 style="color: #003366; text-transform: uppercase; margin: 0;">User Management</h1>
                    <p style="color: #888; margin: 5px 0 0; font-size: 0.85rem;">Reviewing all system accounts</p>
                </div>
                <div style="display: flex; gap: 20px; align-items: center;">
                    <div class="role-toggle">
                        <button class="toggle-btn active" onclick="showTab('student-tab', this)"><i class="fas fa-user-graduate"></i> Students</button>
                        <button class="toggle-btn" onclick="showTab('driver-tab', this)"><i class="fas fa-car-side"></i> Drivers</button>
                        <button class="toggle-btn" onclick="showTab('admin-tab', this)"><i class="fas fa-user-shield"></i> Admins</button>
                    </div>
                    <a href="admin-add-users.php" class="btn-add"><i class="fas fa-plus-circle"></i> Create User</a>
                </div>
            </div>

            <div id="student-tab" class="tab-content">
                <div class="table-container" style="overflow-x: auto;">
                    <table class="admin-table">
                        <thead>
                            <tr>
                                <th>User ID</th><th>Full Name</th><th>Email</th><th>Phone</th><th>TP Number</th><th>Emergency</th><th style="text-align: center;">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($row = mysqli_fetch_assoc($students)): ?>
                            <tr id="row-<?= $row['user_id'] ?>">
                                <td><code><?= $row['user_id'] ?></code></td>
                                <td><input type="text" name="full_name" class="inline-input" value="<?= $row['full_name'] ?>" readonly oninput="detectedChange('<?= $row['user_id'] ?>')"></td>
                                <td><input type="text" name="email" class="inline-input" value="<?= $row['email'] ?>" readonly oninput="detectedChange('<?= $row['user_id'] ?>')"></td>
                                <td><input type="text" name="phone_number" class="inline-input" value="<?= $row['phone_number'] ?>" readonly oninput="detectedChange('<?= $row['user_id'] ?>')"></td>
                                <td><input type="text" name="tp_number" class="inline-input" value="<?= $row['tp_number'] ?>" readonly oninput="detectedChange('<?= $row['user_id'] ?>')"></td>
                                <td><input type="text" name="emergency_contact" class="inline-input" value="<?= $row['emergency_contact'] ?>" readonly oninput="detectedChange('<?= $row['user_id'] ?>')"></td>
                                <td style="text-align: center; white-space: nowrap;">
                                    <button class="btn-action btn-edit" id="btn-edit-<?= $row['user_id'] ?>" onclick="enableRow('<?= $row['user_id'] ?>')"><i class="fas fa-user-edit"></i></button>
                                    <button class="btn-action btn-confirm" id="btn-tick-<?= $row['user_id'] ?>" style="display:none;" onclick="updateRow('<?= $row['user_id'] ?>', 'student')"><i class="fas fa-check"></i></button>
                                    <a href="admin-users.php?delete_id=<?= $row['user_id'] ?>" class="btn-action btn-delete" onclick="return confirm('Delete?')"><i class="fas fa-trash-alt"></i></a>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div id="driver-tab" class="tab-content" style="display:none;">
                <div class="table-container" style="overflow-x: auto;">
                    <table class="admin-table">
                        <thead>
                            <tr>
                                <th>User ID</th><th>Full Name</th><th>Email</th><th>Phone</th><th>License</th><th>Car Model</th><th>Plate</th><th>Rating</th><th style="text-align: center;">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($row = mysqli_fetch_assoc($drivers)): ?>
                            <tr id="row-<?= $row['user_id'] ?>">
                                <td><code><?= $row['user_id'] ?></code></td>
                                <td><input type="text" name="full_name" class="inline-input" value="<?= $row['full_name'] ?>" readonly oninput="detectedChange('<?= $row['user_id'] ?>')"></td>
                                <td><input type="text" name="email" class="inline-input" value="<?= $row['email'] ?>" readonly oninput="detectedChange('<?= $row['user_id'] ?>')"></td>
                                <td><input type="text" name="phone_number" class="inline-input" value="<?= $row['phone_number'] ?>" readonly oninput="detectedChange('<?= $row['user_id'] ?>')"></td>
                                <td><input type="text" name="license_number" class="inline-input" value="<?= $row['license_number'] ?>" readonly oninput="detectedChange('<?= $row['user_id'] ?>')"></td>
                                <td><input type="text" name="car_model" class="inline-input" value="<?= $row['car_model'] ?>" readonly oninput="detectedChange('<?= $row['user_id'] ?>')"></td>
                                <td><input type="text" name="plate_number" class="inline-input" value="<?= $row['plate_number'] ?>" readonly oninput="detectedChange('<?= $row['user_id'] ?>')"></td>
                                <td><input type="number" step="0.1" name="driver_rating" class="inline-input" style="width:50px" value="<?= $row['driver_rating'] ?>" readonly oninput="detectedChange('<?= $row['user_id'] ?>')"></td>
                                <td style="text-align: center; white-space: nowrap;">
                                    <button class="btn-action btn-edit" id="btn-edit-<?= $row['user_id'] ?>" onclick="enableRow('<?= $row['user_id'] ?>')"><i class="fas fa-user-edit"></i></button>
                                    <button class="btn-action btn-confirm" id="btn-tick-<?= $row['user_id'] ?>" style="display:none;" onclick="updateRow('<?= $row['user_id'] ?>', 'driver')"><i class="fas fa-check"></i></button>
                                    <a href="admin-users.php?delete_id=<?= $row['user_id'] ?>" class="btn-action btn-delete" onclick="return confirm('Delete?')"><i class="fas fa-trash-alt"></i></a>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div id="admin-tab" class="tab-content" style="display:none;">
                <div class="table-container" style="overflow-x: auto;">
                    <table class="admin-table">
                        <thead>
                            <tr>
                                <th>User ID</th>
                                <th>Full Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th style="text-align: center;">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($row = mysqli_fetch_assoc($admins)): ?>
                            <tr id="row-<?= $row['user_id'] ?>">
                                <td><code><?= $row['user_id'] ?></code></td>
                                <td><input type="text" name="full_name" class="inline-input" value="<?= $row['full_name'] ?>" readonly oninput="detectedChange('<?= $row['user_id'] ?>')"></td>
                                <td><input type="text" name="email" class="inline-input" value="<?= $row['email'] ?>" readonly oninput="detectedChange('<?= $row['user_id'] ?>')"></td>
                                <td><input type="text" name="phone_number" class="inline-input" value="<?= $row['phone_number'] ?>" readonly oninput="detectedChange('<?= $row['user_id'] ?>')"></td>
                                <td style="text-align: center; white-space: nowrap;">
                                    <button class="btn-action btn-edit" id="btn-edit-<?= $row['user_id'] ?>" onclick="enableRow('<?= $row['user_id'] ?>')">
                                        <i class="fas fa-user-edit"></i>
                                    </button>
                                    <button class="btn-action btn-confirm" id="btn-tick-<?= $row['user_id'] ?>" style="display:none;" onclick="updateRow('<?= $row['user_id'] ?>', 'admin')">
                                        <i class="fas fa-check"></i>
                                    </button>
                                    <?php if($row['user_id'] !== $current_admin): ?>
                                        <a href="admin-users.php?delete_id=<?= $row['user_id'] ?>" class="btn-action btn-delete" onclick="return confirm('Delete this Admin?')">
                                            <i class="fas fa-trash-alt"></i>
                                        </a>
                                    <?php else: ?>
                                        <span style="font-size: 10px; color: #003366; font-weight: bold; background: #eef; padding: 4px 8px; border-radius: 4px;">
                                            <i class="fas fa-lock"></i> YOU
                                        </span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script>
    function showTab(id, btn) {
        document.querySelectorAll('.tab-content').forEach(t => t.style.display = 'none');
        document.querySelectorAll('.toggle-btn').forEach(b => b.classList.remove('active'));
        document.getElementById(id).style.display = 'block';
        btn.classList.add('active');
    }

    function enableRow(uid) {
        const inputs = document.querySelectorAll(`#row-${uid} input`);
        inputs.forEach(input => input.readOnly = !input.readOnly);
        if (inputs.length > 0 && !inputs[0].readOnly) inputs[0].focus();
    }

    function detectedChange(uid) {
        document.getElementById('btn-edit-' + uid).style.display = 'none';
        document.getElementById('btn-tick-' + uid).style.display = 'inline-flex';
    }

    function updateRow(uid, type) {
        const row = document.getElementById('row-' + uid);
        const inputs = row.querySelectorAll('input');
        let formData = { user_id: uid, user_type: type };
        
        //Collect all input values
        inputs.forEach(input => formData[input.name] = input.value);

        fetch('admin-update-users.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(formData)
        })
        .then(response => response.json())
        .then(data => {
            if(data.success) { 
                //Show the success popup
                alert("✅ User updated successfully!"); 

                //Lock the inputs again
                inputs.forEach(input => input.readOnly = true);

                //Switch buttons back: Hide Tick, Show Edit
                document.getElementById('btn-tick-' + uid).style.display = 'none';
                document.getElementById('btn-edit-' + uid).style.display = 'inline-flex';
                
                //Reload to ensure all data is synced with database state
                location.reload(); 
            } else { 
                alert("❌ Error: " + data.message); 
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert("❌ A system error occurred.");
        });
    }
    </script>
</body>
</html>