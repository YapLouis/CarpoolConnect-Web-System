<?php
$host = "localhost";
$dbname = "apu_carpool_connect";
$username = "root"; 
$password = ""; 

//Create connection
$conn = mysqli_connect($host, $username, $password, $dbname);

//Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

function getEstimatedRoadDist($lat1, $lon1, $lat2, $lon2) {
    $R = 6371; //Earth radius in km
    $dLat = deg2rad($lat2 - $lat1);
    $dLon = deg2rad($lon2 - $lon1);
    $a = sin($dLat/2)**2 + cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * sin($dLon/2)**2;
    $straightDist = $R * 2 * atan2(sqrt($a), sqrt(1-$a));
    
    return $straightDist * 1.3;
}

//Centralized Total Fare Calculation
function calculateTotalFare($distance) {
    $ratePerKm = 1.50;
    return $distance * $ratePerKm;
}

//Centralized Carbon Saving Logic
function calculateCO2Saved($distance) {
    $avgKgPerKm = 0.2;
    return $distance * $avgKgPerKm;
}

//Centralized Eco-Points Logic
function calculateEcoPoints($distance) {
    //Get the carbon saved using our existing logic
    $co2 = calculateCO2Saved($distance);
    
    //Formula: Carbon Saved * 100
    return round($co2 * 100);
}