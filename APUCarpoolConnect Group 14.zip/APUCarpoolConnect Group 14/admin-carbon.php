<?php
include 'db.php';
include 'admin-header.php';

//AGGREGATE STATS
$stats_query = mysqli_query($conn, "SELECT SUM(distance) as total_dist, SUM(co2_saved) as total_co2 FROM carbon_tracking_table");
$stats = mysqli_fetch_assoc($stats_query);

$ride_count_query = mysqli_query($conn, "SELECT COUNT(carbon_id) as total_rides FROM carbon_tracking_table");
$ride_count = mysqli_fetch_assoc($ride_count_query);

//TOP ECO-DRIVERS LEADERBOARD
$leaderboard_sql = "SELECT u.full_name, SUM(ct.co2_saved) as savings, COUNT(ct.ride_id) as ride_qty 
                    FROM user_table u 
                    JOIN rides_table r ON u.user_id = r.driver_id 
                    JOIN carbon_tracking_table ct ON r.ride_id = ct.ride_id 
                    GROUP BY u.user_id 
                    ORDER BY savings DESC LIMIT 5";
$leaderboard = mysqli_query($conn, $leaderboard_sql);

//RECENT SAVINGS LOG
$logs_sql = "SELECT ct.*, r.departure_time, l1.location_name as pickup, l2.location_name as dropoff 
             FROM carbon_tracking_table ct
             JOIN rides_table r ON ct.ride_id = r.ride_id
             JOIN location_table l1 ON r.pickup_id = l1.location_id
             JOIN location_table l2 ON r.dropoff_id = l2.location_id
             ORDER BY r.departure_time DESC LIMIT 10";
$logs = mysqli_query($conn, $logs_sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Carbon Impact Report - APU Carpool</title>
    <link rel="stylesheet" href="admin-style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .impact-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .impact-card {
            background: #fff;
            padding: 25px 15px;
            border-radius: 12px;
            text-align: center;
            border: 1px solid #eee;
            transition: transform 0.3s ease;
        }

        .impact-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.05);
        }

        .impact-card i {
            font-size: 2rem;
            color: #2ecc71;
            margin-bottom: 15px;
        }

        .impact-card h2 {
            font-size: 1.8rem;
            color: #003366;
            margin: 5px 0;
            font-weight: 800;
        }

        .impact-card p {
            font-size: 0.8rem;
            color: #777;
            text-transform: uppercase;
            letter-spacing: 1px;
            font-weight: 600;
        }

        .badge-savings {
            background: #e8f5e9;
            color: #2e7d32;
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: bold;
        }

        .log-table-container {
            background: white;
            padding: 20px;
            border-radius: 12px;
            border: 1px solid #eee;
        }
    </style>
</head>
<body style="overflow: auto;">

<div class="main-content" style="display: block !important; padding-top: 20px !important;">
    <div class="content-wrapper" style="margin: auto; max-width: 95%;">
        
        <div style="text-align: center; margin-bottom: 30px;">
            <h1 style="color: #003366; text-transform: uppercase; margin: 0; font-size: 2.2rem; font-weight: 800; letter-spacing: 1px;">Sustainability Report</h1>
            <p style="color: #888; font-size: 0.95rem; margin-top: 5px;">Tracking our collective environmental impact at APU</p>
        </div>

        <div class="impact-grid">
            <div class="impact-card">
                <i class="fas fa-leaf"></i>
                <h2><?= number_format($stats['total_co2'] ?? 0, 2) ?> kg</h2>
                <p>Total CO2 Saved</p>
            </div>
            <div class="impact-card">
                <i class="fas fa-route"></i>
                <h2><?= number_format($stats['total_dist'] ?? 0, 1) ?> km</h2>
                <p>Green Distance</p>
            </div>
            <div class="impact-card">
                <i class="fas fa-smog"></i>
                <h2><?= $ride_count['total_rides'] ?? 0 ?></h2>
                <p>Reduced Trips</p>
            </div>
            <div class="impact-card">
                <i class="fas fa-tree"></i>
                <h2><?= floor(($stats['total_co2'] ?? 0) / 21) ?></h2>
                <p>Trees Equivalent*</p>
            </div>
        </div>

        <div style="display: grid; grid-template-columns: 1fr 2fr; gap: 25px; align-items: start;">
            
            <div class="log-table-container">
                <h3 style="color: #003366; margin-bottom: 15px; font-size: 1.1rem;"><i class="fas fa-trophy" style="color: #f1c40f;"></i> Top Eco-Drivers</h3>
                <table style="width: 100%; border-collapse: collapse;">
                    <thead>
                        <tr style="text-align: left; border-bottom: 2px solid #eee;">
                            <th style="padding: 10px 5px; color: #666; font-size: 0.8rem;">DRIVER</th>
                            <th style="padding: 10px 5px; color: #666; font-size: 0.8rem; text-align: right;">IMPACT</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($row = mysqli_fetch_assoc($leaderboard)): ?>
                        <tr style="border-bottom: 1px solid #fafafa;">
                            <td style="padding: 12px 5px;">
                                <span style="font-weight: 700; color: #333;"><?= $row['full_name'] ?></span><br>
                                <small style="color: #999;"><?= $row['ride_qty'] ?> rides completed</small>
                            </td>
                            <td style="padding: 12px 5px; text-align: right;">
                                <span class="badge-savings"><?= number_format($row['savings'], 1) ?> kg</span>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>

            <div class="log-table-container">
                <h3 style="color: #003366; margin-bottom: 15px; font-size: 1.1rem;"><i class="fas fa-history"></i> Recent Carbon Savings</h3>
                <table style="width: 100%; border-collapse: collapse;">
                    <thead>
                        <tr style="text-align: left; border-bottom: 2px solid #eee;">
                            <th style="padding: 10px; color: #666; font-size: 0.8rem;">RIDE</th>
                            <th style="padding: 10px; color: #666; font-size: 0.8rem;">ROUTE</th>
                            <th style="padding: 10px; color: #666; font-size: 0.8rem;">DIST.</th>
                            <th style="padding: 10px; color: #666; font-size: 0.8rem; text-align: right;">SAVED</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($log = mysqli_fetch_assoc($logs)): ?>
                        <tr style="border-bottom: 1px solid #fafafa;">
                            <td style="padding: 15px 10px; font-weight: bold; color: #003366;"><?= $log['ride_id'] ?></td>
                            <td style="padding: 15px 10px;">
                                <div style="font-size: 0.85rem; color: #444;"><?= $log['pickup'] ?></div>
                                <div style="font-size: 0.75rem; color: #999;"><i class="fas fa-arrow-down" style="font-size: 10px;"></i> <?= $log['dropoff'] ?></div>
                            </td>
                            <td style="padding: 15px 10px; color: #666; font-size: 0.9rem;"><?= $log['distance'] ?> km</td>
                            <td style="padding: 15px 10px; text-align: right; color: #27ae60; font-weight: 800;">+<?= $log['co2_saved'] ?> kg</td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>

        </div>

        <div style="margin-top: 25px; padding: 15px; background: #f8f9fa; border-left: 4px solid #2ecc71; border-radius: 4px;">
            <p style="margin: 0; font-size: 0.85rem; color: #666; line-height: 1.5;">
                <strong>How is this calculated?</strong> We estimate CO2 savings based on the distance of the carpool trip multiplied by the average emissions of a standard passenger vehicle, divided by the number of occupants. 
                <br><span style="font-style: italic;">* One mature tree absorbs approximately 21kg of CO2 per year.</span>
            </p>
        </div>
        
    </div>
</div>

</body>
</html>