<?php
if (session_status() === PHP_SESSION_NONE) session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

$admin_name = $_SESSION['full_name'] ?? "Admin";
$page = basename($_SERVER['PHP_SELF']);

//Helper function to check active state
function isActive($page, $targets) {
    return in_array($page, (array)$targets) ? 'active' : '';
}
?>

<link rel="stylesheet" href="admin-style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

<header class="header">
    <div class="logo-section">
        <img src="apucarpoolconnectlogo-header.png" alt="Logo" style="height: 40px; width: auto; display: block;">
    </div>

    <nav class="nav-menu">
        <a href="admin-home.php" class="nav-link <?= isActive($page, 'admin-home.php') ?>"><i class="fas fa-home"></i> Home</a>
        <a href="admin-users.php" class="nav-link <?= isActive($page, ['admin-users.php', 'admin-add-users.php']) ?>"><i class="fas fa-users-cog"></i> Users</a>
        <a href="admin-rides.php" class="nav-link <?= isActive($page, ['admin-rides.php', 'admin-add-rides.php', 'admin-add-location.php']) ?>"><i class="fas fa-car"></i> Rides</a>
        <a href="admin-rewards.php" class="nav-link <?= isActive($page, ['admin-rewards.php','admin-add-reward.php']) ?>"><i class="fas fa-gift"></i> Rewards</a>
        <a href="admin-carbon.php" class="nav-link <?= isActive($page, 'admin-carbon.php') ?>"><i class="fas fa-leaf"></i> Carbon</a>
    </nav>

    <div class="profile-section">
        <div class="profile-container" onclick="toggleDropdown()">
            <i class="fas fa-user-circle" style="font-size: 32px; color: #333; cursor: pointer;"></i>
            <div id="myDropdown" class="dropdown">
                <p style="padding: 10px; margin: 0; font-size: 11px; color: #999; text-align: center;">ADMIN: <?= htmlspecialchars($admin_name) ?></p>
                <hr style="border: 0; border-top: 1px solid #eee; margin: 0;">
                <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </div>
    </div>
</header>

<script>
    const dropdown = document.getElementById("myDropdown");
    const toggleDropdown = () => dropdown.classList.toggle("show");

    window.onclick = (e) => {
        if (!e.target.closest('.profile-container')) dropdown.classList.remove('show');
    }
</script>