<?php
include 'db.php';
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'student') {
    header("Location: login.php"); exit();
}

//Fetch locations for dropdowns and map
$locationsQuery = "SELECT * FROM location_table";
$locationsResult = mysqli_query($conn, $locationsQuery);
$locationsArray = mysqli_fetch_all($locationsResult, MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Homepage - APU Carpool</title>
    <link rel="stylesheet" href="student.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <style>
        .pickup-label { color: #444444 !important; font-weight: 900; }
        .dropoff-label { color: #28a745 !important; font-weight: 900; }
        .left-panel { min-height: 400px; }
    </style>
</head>
<body class="scroll-body">

    <?php include 'student-header.php'; ?>

    <div class="container" style="max-width: 1400px; margin: 0 auto; padding: 20px;">
        <div class="main-content">
            <div class="left-panel">
                <h3>Find a Ride</h3>
                <form class="form-group" method="GET" action="view-rides.php">
                    <label class="pickup-label">Pickup Location:</label>
                    <select name="pickup" id="pickup_select" class="input" onchange="updateMapMarkers(); calculateLiveFare();" required>
                        <option value="">Select Pickup</option>
                        <?php foreach($locationsArray as $loc): ?>
                            <option value="<?= $loc['location_id'] ?>" data-lat="<?= $loc['latitude'] ?>" data-lng="<?= $loc['longitude'] ?>">
                                <?= $loc['location_name'] ?>
                            </option>
                        <?php endforeach; ?>
                    </select>

                    <label class="dropoff-label" style="margin-top: 15px;">Drop-off Location:</label>
                    <select name="dropoff" id="dropoff_select" class="input" onchange="updateMapMarkers(); calculateLiveFare();" required>
                        <option value="">Select Drop-off</option>
                        <?php foreach($locationsArray as $loc): ?>
                            <option value="<?= $loc['location_id'] ?>" data-lat="<?= $loc['latitude'] ?>" data-lng="<?= $loc['longitude'] ?>">
                                <?= $loc['location_name'] ?>
                            </option>
                        <?php endforeach; ?>
                    </select>

                    <div id="fare_display" style="display:none; margin: 15px 0; padding: 12px; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 10px;">
                        <p style="margin: 0; font-size: 0.9rem;">📏 Distance: <strong><span id="dist_val">0</span> km</strong></p>
                        <p style="margin: 5px 0 0 0; color: #166534; font-weight: bold;">💰 Est. Fare: RM <span id="fare_val">0.00</span></p>
                    </div>

                    <button type="submit" class="btn student" style="width: 100%; margin-top: 10px;">Search Rides</button>
                </form>
            </div>

            <div class="right-panel">
                <div id="map"></div>
            </div>
        </div>
    </div>

    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <script>
        var map = L.map('map').setView([3.0487, 101.6944], 15);
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(map);

        function createIcon(color) {
            return L.divIcon({ 
                className: "custom-pin", 
                html: `<svg width="30" height="42" viewBox="0 0 24 24" fill="${color}" xmlns="http://www.w3.org/2000/svg"><path d="M12 0C7.58 0 4 3.58 4 8c0 5.25 8 13 8 13s8-7.75 8-13c0-4.42-3.58-8-8-8zm0 11c-1.66 0-3-1.34-3-3s1.34-3 3-3 3 1.34 3 3-1.34 3-3 3z"/></svg>`, 
                iconSize: [30, 42], 
                iconAnchor: [15, 42] 
            });
        }

        var greyIcon = createIcon("#444444"), 
            greenIcon = createIcon("#28a745"), 
            pickupMarker, 
            dropoffMarker;

        function updateMapMarkers() {
            const p = document.getElementById('pickup_select').selectedOptions[0];
            const d = document.getElementById('dropoff_select').selectedOptions[0];
            
            if (p.value) {
                if (pickupMarker) map.removeLayer(pickupMarker);
                pickupMarker = L.marker([p.dataset.lat, p.dataset.lng], {icon: greyIcon}).addTo(map);
            }
            if (d.value) {
                if (dropoffMarker) map.removeLayer(dropoffMarker);
                dropoffMarker = L.marker([d.dataset.lat, d.dataset.lng], {icon: greenIcon}).addTo(map);
            }
            
            // Auto-zoom if both selected
            if (p.value && d.value) {
                var group = new L.featureGroup([pickupMarker, dropoffMarker]);
                map.fitBounds(group.getBounds().pad(0.5));
            }
        }

        function calculateLiveFare() {
            const p = document.getElementById('pickup_select').selectedOptions[0];
            const d = document.getElementById('dropoff_select').selectedOptions[0];
            
            if (p.value && d.value) {
                const lat1 = parseFloat(p.dataset.lat), lon1 = parseFloat(p.dataset.lng);
                const lat2 = parseFloat(d.dataset.lat), lon2 = parseFloat(d.dataset.lng);
                
                //Haversine Formula 
                const R = 6371;
                const dLat = (lat2-lat1)*Math.PI/180, dLon = (lon2-lon1)*Math.PI/180;
                const a = Math.sin(dLat/2)**2 + Math.cos(lat1*Math.PI/180)*Math.cos(lat2*Math.PI/180)*Math.sin(dLon/2)**2;
                const straightDistance = R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
                
                //Apply 1.3 circuity factor for road estimation
                const estimatedRoadDistance = straightDistance * 1.3;
                
                //Update the UI
                document.getElementById('dist_val').innerText = estimatedRoadDistance.toFixed(2);
                
                //Calculate Fare based on adjusted distance (RM 1.50 per km)
                const totalFare = (estimatedRoadDistance * 1.5).toFixed(2);
                document.getElementById('fare_val').innerText = totalFare;
                
                document.getElementById('fare_display').style.display = 'block';
            }
        }
    </script>
</body>
</html>