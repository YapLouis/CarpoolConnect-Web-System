<?php
    include 'db.php';
    session_start();

    //When btnRegister was clicked
    if(isset($_POST['btnRegister'])){
        $fullname = $_POST['full_name'];
        $tp_number = $_POST['tp_number'];
        $phone_number = $_POST['phone_number']; 
        $emergency_contact = $_POST['emergency_contact']; 
        $email = $_POST['email'];
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

        //Auto Increment (US001,US002)
        $idQuery = "SELECT user_id FROM user_table ORDER BY user_id DESC LIMIT 1";
        $idResult = mysqli_query($conn, $idQuery);
        
        if (mysqli_num_rows(result: $idResult) > 0) {
            $last_user = mysqli_fetch_assoc(result: $idResult);
            //Extract the number from "US002" -> 2 and increment
            $last_number = (int)substr($last_user['user_id'], 2);
            $new_number = $last_number + 1;
        } else {
            $new_number = 1;
        }
        //Format to US001, US002, etc.
        $user_id = "US" . str_pad($new_number, 3, "0", STR_PAD_LEFT);

        // --- 2. INSERT INTO user_table ---
        $query1 = "INSERT INTO user_table (user_id, full_name, email, password, phone_number, role) 
                   VALUES ('$user_id', '$fullname', '$email', '$password', '$phone_number', 'student')";
        $result1 = mysqli_query($conn, $query1);

        // --- 3. INSERT INTO student_details_table ---
        $query2 = "INSERT INTO student_details_table (student_id, tp_number, emergency_contact) 
                   VALUES ('$user_id', '$tp_number', '$emergency_contact')";
        $result2 = mysqli_query($conn, $query2);

        // Check if both database inserts were successful
        if($result1 && $result2){
            echo "<script>alert('Registered Successfully!'); window.location.href='index.html';</script>";
            exit();
        } else {
            // This will tell you EXACTLY what is wrong with the SQL
            echo "Error 1: " . mysqli_error($conn) . "<br>";
            if (!$result2) {
                echo "Error in Student Details Table: " . mysqli_error($conn);
            }
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Registration - APU Carpool</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="scroll-body"> <div class="container registration-box">
        <img src="apucarpoolconnectlogo.png" alt="APU Carpool Logo" class="app-logo">
        
        <h1>STUDENT REGISTER</h1>
        <p>Please fill in your details to join</p>

        <form class="form-group" method="POST" action="register-student.php">
            <input type="text" name="full_name" placeholder="Full Name" required>
            <input type="text" name="tp_number" placeholder="TP Number (e.g. TP012345)" required>
            
            <input type="tel" name="phone_number" placeholder="Phone Number" required>
            <input type="tel" name="emergency_contact" placeholder="Emergency Contact No." required>
            
            <input type="email" name="email" placeholder="APU Student Email" required>
            <input type="password" name="password" placeholder="Create Password" required>

            <div class="button-group">
                <a href="index.html" class="btn driver">Back</a>
                <button type="submit" name="btnRegister" class="btn student">Register Now</button>
            </div>
        </form>
    </div>
</body>
</html>