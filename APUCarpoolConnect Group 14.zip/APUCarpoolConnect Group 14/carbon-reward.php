<?php
include 'db.php';
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'student') {
    header("Location: login.php"); exit();
}

$student_id = $_SESSION['user_id'];

//Fetch Total Points From Database
$pointQuery = "SELECT total_points FROM student_details_table WHERE student_id = '$student_id'";
$pointRes = mysqli_query($conn, $pointQuery);
$current_points = 0; 

if ($pointRes && mysqli_num_rows($pointRes) > 0) {
    $pointData = mysqli_fetch_assoc($pointRes);
    $current_points = $pointData['total_points'];
}

//Fetch Total Carbon Saved (Calculated live from approved ride coordinates)
$carbonQuery = "SELECT lp.latitude as p_lat, lp.longitude as p_lng, ld.latitude as d_lat, ld.longitude as d_lng
                FROM carpool_request_table cr
                JOIN rides_table r ON cr.ride_id = r.ride_id
                JOIN location_table lp ON r.pickup_id = lp.location_id
                JOIN location_table ld ON r.dropoff_id = ld.location_id
                WHERE cr.student_id = '$student_id' AND cr.status = 'approved'";

$carbonRes = mysqli_query($conn, $carbonQuery);
$total_co2 = 0;

while($row = mysqli_fetch_assoc($carbonRes)) {
    //Using the established function: getEstimatedRoadDist
    $dist = getEstimatedRoadDist($row['p_lat'], $row['p_lng'], $row['d_lat'], $row['d_lng']);
    //Using the established function: calculateCO2Saved
    $total_co2 += calculateCO2Saved($dist);
}

//Fetch Master Voucher List
$voucherQuery = "SELECT * FROM voucher_list_table WHERE voucher_status = 1 AND stock_quantity > 0";
$vouchers = mysqli_query($conn, $voucherQuery);
?>
    
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Eco Rewards - APU Carpool</title>
    <link rel="stylesheet" href="student.css">
</head>
<body>
    <?php include 'student-header.php'; ?>

    <div class="reward-dashboard" style="max-width: 1000px; margin: 0 auto; padding: 20px;">
        
        <div class="history-nav" style="text-align: right; margin-bottom: 20px;">
            <a href="point-history.php" class="btn student" style="background:#333;">📜 View Point History</a>
        </div>

        <div class="dashboard-top" style="display: flex; gap: 20px; margin-bottom: 40px;">
            <div class="reward-card carbon-box" style="flex: 1; background: white; padding: 20px; border-radius: 15px; text-align: center; box-shadow: 0 4px 10px rgba(0,0,0,0.05);">
                <h3>Total CO₂ Saved</h3>
                <div class="value" style="font-size: 2.5rem; font-weight: bold; color: #2e7d32;"><?= number_format($total_co2, 2) ?> <span class="unit">kg</span></div>
            </div>

            <div class="reward-card points-box" style="flex: 1; background: white; padding: 20px; border-radius: 15px; text-align: center; box-shadow: 0 4px 10px rgba(0,0,0,0.05);">
                <h3>Points Available</h3>
                <div class="value" style="font-size: 2.5rem; font-weight: bold; color: #007bff;"><?= number_format($current_points) ?> <span class="unit">pts</span></div>
            </div>
        </div>

        <div class="voucher-section">
            <h2 style="border-left: 5px solid #28a745; padding-left: 15px;">🎁 Available Vouchers</h2>
            <div class="voucher-grid" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 20px; margin-top:20px;">
                <?php 
                mysqli_data_seek($vouchers, 0); 
                while($v = mysqli_fetch_assoc($vouchers)): 
                    $v_id = $v['voucher_id'];
                    // Logic fix: Only hide voucher if student currently owns an AVAILABLE (un-used) version of it
                    $checkOwned = mysqli_query($conn, "SELECT 1 FROM voucher_redemption_table WHERE user_id = '$student_id' AND voucher_id = '$v_id' AND redemption_status = 'available' LIMIT 1");
                    
                    if (mysqli_num_rows($checkOwned) == 0):
                ?>
                    <div class="v-item" style="background: white; padding: 20px; border-radius: 12px; border: 1px solid #eee;">
                        <h4 style="margin-top: 0;"><?= htmlspecialchars($v['voucher_name']) ?></h4>
                        <p style="font-size: 0.8rem; color: #777;"><?= htmlspecialchars($v['terms_conditions']) ?></p>
                        <div style="font-weight: bold; color: #333; margin-bottom: 15px;"><?= number_format($v['point_cost']) ?> Points</div>
                        
                        <form action="redeem-action.php" method="POST">
                            <input type="hidden" name="voucher_id" value="<?= $v_id ?>">
                            <?php if ($current_points >= $v['point_cost']): ?>
                                <button type="submit" class="btn student" style="width: 100%;">
                                    Redeem Now
                                </button>
                            <?php else: ?>
                                <button type="button" class="btn" style="width: 100%; background: #ccc; color: #777; cursor: not-allowed; border: none;" disabled>
                                    Insufficient Points
                                </button>
                            <?php endif; ?>
                        </form>
                    </div>
                <?php endif; endwhile; ?>
            </div>
        </div>

        <hr style="border: 0; border-top: 2px dashed #ddd; margin: 50px 0;">

        <div class="voucher-section">
            <h2 id="my-vouchers" style="border-left: 5px solid #3498db; padding-left: 15px;">🎟️ My Vouchers</h2>
            <div class="voucher-grid" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 20px; margin-top:20px;">
                <?php 
                $myVoucherQuery = "SELECT r.*, v.voucher_name, v.terms_conditions 
                                    FROM voucher_redemption_table r 
                                    JOIN voucher_list_table v ON r.voucher_id = v.voucher_id 
                                    WHERE r.user_id = '$student_id'
                                    ORDER BY r.redemption_date DESC";
                $myVouchers = mysqli_query($conn, $myVoucherQuery);

                if (mysqli_num_rows($myVouchers) > 0):
                    while($my = mysqli_fetch_assoc($myVouchers)): 
                        $isUsed = ($my['redemption_status'] == 'unavailable');
                ?>
                    <div class="v-item" style="padding: 20px; border-radius: 12px; background: white; border: 2px solid <?= $isUsed ? '#27ae60' : '#3498db' ?>;">
                        <h4 style="margin-top: 0;"><?= htmlspecialchars($my['voucher_name']) ?></h4>
                        
                        <?php if (!$isUsed): ?>
                            <p style="font-size: 0.8rem; color: #666;"><?= htmlspecialchars($my['terms_conditions']) ?></p>
                            <div style="background:#fff3cd; padding:10px; border-radius:8px; margin-top:10px; text-align:center;">
                                <form action="use-voucher-action.php" method="POST" onsubmit="return confirm('Use this voucher now?');">
                                    <input type="hidden" name="redemption_id" value="<?= $my['redemption_id'] ?>">
                                    <button type="submit" class="btn" style="background:#f39c12; color:white; width:100%; border:none; padding:8px; border-radius:5px; cursor:pointer;">Use Now</button>
                                </form>
                            </div>
                        <?php else: ?>
                            <?php 
                                $displayCode = !empty($my['unique_code']) ? $my['unique_code'] : "APU-" . $my['redemption_id'] . "-" . strtoupper(substr(md5($my['redemption_id']), 0, 4));
                                $expiryDate = date('d M Y', strtotime($my['redemption_date'] . ' + 30 days'));
                            ?>
                            <div class="used-voucher-box">
                                <div style="font-family: monospace; font-size: 1.1rem; font-weight: bold; background: #e8f5e9; color: #27ae60; border: 1px dashed #27ae60; padding: 10px; text-align: center; margin-bottom: 10px;">
                                    <?= $displayCode ?>
                                </div>
                                <div style="text-align: left; font-size: 0.75rem; color: #555;">
                                    <strong>Redeemed:</strong> <?= date('d M Y', strtotime($my['redemption_date'])) ?><br>
                                    <strong>Expires:</strong> <span style="color: #e74c3c;"><?= $expiryDate ?></span><br>
                                    <strong>Terms:</strong> <?= htmlspecialchars($my['terms_conditions']) ?>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endwhile; 
                else: ?>
                    <p style="color: #999;">You haven't redeemed any vouchers yet.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>