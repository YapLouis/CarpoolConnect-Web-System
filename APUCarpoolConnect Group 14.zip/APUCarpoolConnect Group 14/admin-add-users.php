<?php
include 'db.php';
include 'admin-header.php';

//AUTO GENERATE USER ID
$res = mysqli_query($conn, "SELECT user_id FROM user_table ORDER BY user_id DESC LIMIT 1");
if (mysqli_num_rows($res) > 0) {
    $row = mysqli_fetch_assoc($res);
    $last_id = $row['user_id']; 
    $number = (int)substr($last_id, 2); 
    $new_id = "US" . str_pad($number + 1, 3, '0', STR_PAD_LEFT);
} else {
    $new_id = "US001";
}

$error_msg = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $uid   = $_POST['user_id'];
    $name  = mysqli_real_escape_string($conn, $_POST['full_name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $pass  = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $phone = mysqli_real_escape_string($conn, $_POST['phone_number']);
    $role  = mysqli_real_escape_string($conn, $_POST['role']);

    //Insert into main user table
    $sql1 = "INSERT INTO user_table (user_id, full_name, email, password, phone_number, role) 
             VALUES ('$uid', '$name', '$email', '$pass', '$phone', '$role')";

    if (mysqli_query($conn, $sql1)) {
        //Insert into specific detail tables only for students and drivers
        if ($role == 'student') {
            $tp = mysqli_real_escape_string($conn, $_POST['tp_number']);
            $em = mysqli_real_escape_string($conn, $_POST['emergency_contact']);
            $sql2 = "INSERT INTO student_details_table (student_id, tp_number, emergency_contact) VALUES ('$uid', '$tp', '$em')";
            mysqli_query($conn, $sql2);
        } else if ($role == 'driver') {
            $ln = mysqli_real_escape_string($conn, $_POST['license_number']);
            $cm = mysqli_real_escape_string($conn, $_POST['car_model']);
            $pn = mysqli_real_escape_string($conn, $_POST['plate_number']);
            $sql2 = "INSERT INTO driver_detail_table (driver_id, license_number, car_model, plate_number, driver_rating) 
                     VALUES ('$uid', '$ln', '$cm', '$pn', 0.00)";
            mysqli_query($conn, $sql2);
        }
        
        //Success for all roles including admin
        echo "<script>alert('User $uid created successfully!'); window.location.href='admin-users.php';</script>";
    } else {
        $error_msg = "Database Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add User - APU Carpool</title>
    <link rel="stylesheet" href="admin-style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * { transition: none !important; animation: none !important; }
        .role-fields { display: none; }
        .readonly-id { background-color: #f0f0f0; cursor: not-allowed; font-weight: bold; color: #003366; }
    </style>
</head>
<body>

<div class="main-content">
    <div class="content-wrapper">
        <div class="welcome-text">
            <h1>Create New User</h1>
            <p>Select a role to register a new account.</p>
        </div>

        <div class="add-user-container" style="margin: 0 auto;">
            <?php if($error_msg) echo "<p style='color:red; text-align:center;'>$error_msg</p>"; ?>

            <form action="admin-add-users.php" method="POST">
                <input type="hidden" name="user_id" value="<?= $new_id ?>">

                <div class="form-section-title">
                    <i class="fas fa-user-shield"></i> Step 1: Account Login (User ID: <?= $new_id ?>)
                </div>

                <div class="input-grid" style="margin-bottom: 0px !important;">
                    <div class="input-group">
                        <label>Assigned User ID</label>
                        <input type="text" class="form-input readonly-id" value="<?= $new_id ?>" readonly 
                            style="background: #f4f4f4; cursor: not-allowed; font-family: monospace; font-weight: bold; color: #555;">
                    </div>
                    
                    <div class="input-group">
                        <label>Full Name</label>
                        <input type="text" name="full_name" class="form-input" placeholder="Full Name" required autofocus>
                    </div>

                    <div class="input-group">
                        <label>Email Address</label>
                        <input type="email" name="email" class="form-input" placeholder="Email Address" required>
                    </div>

                    <div class="input-group">
                        <label>Password</label>
                        <input type="password" name="password" class="form-input" placeholder="Create Password" required>
                    </div>

                    <div class="input-group">
                        <label>Phone Number</label>
                        <input type="text" name="phone_number" class="form-input" placeholder="012-3456789" required>
                    </div>

                    <div class="input-group">
                        <label>Select User Role</label>
                        <select name="role" id="roleSelect" class="form-input" onchange="toggleSections()" required>
                            <option value="" disabled selected>-- Choose Role --</option>
                            <option value="student">Student</option>
                            <option value="driver">Driver</option>
                            <option value="admin">Admin</option>
                        </select>
                    </div>
                </div>

                <div id="studentSection" class="role-fields">
                    <div class="form-section-title">Step 2: Student Details</div>
                    <div class="input-grid">
                        <div class="input-group">
                            <label>TP Number</label>
                            <input type="text" name="tp_number" id="tp_input" class="form-input" placeholder="TP012345">
                        </div>
                        <div class="input-group">
                            <label>Emergency Contact</label>
                            <input type="text" name="emergency_contact" id="em_input" class="form-input" placeholder="Emergency Contact No.">
                        </div>
                    </div>
                </div>

                <div id="driverSection" class="role-fields">
                    <div class="form-section-title">Step 2: Vehicle & Driver Details</div>
                    <div class="input-grid">
                        <div class="input-group">
                            <label>License Number</label>
                            <input type="text" name="license_number" id="lic_input" class="form-input" placeholder="License Number">
                        </div>
                        <div class="input-group">
                            <label>Car Model</label>
                            <input type="text" name="car_model" id="car_input" class="form-input" placeholder="Perodua Myvi">
                        </div>
                        <div class="input-group full">
                            <label>Plate Number</label>
                            <input type="text" name="plate_number" id="plate_input" class="form-input" placeholder="VBH 1234">
                        </div>
                    </div>
                </div>

                <button type="submit" class="btn-submit-user">REGISTER ACCOUNT</button>
                <div style="text-align: center; margin-top: 15px;">
                    <a href="admin-users.php" style="color: #999; text-decoration: none; font-size: 12px; font-weight: bold;">CANCEL</a>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function toggleSections() {
    var role = document.getElementById('roleSelect').value;
    var sSec = document.getElementById('studentSection'), dSec = document.getElementById('driverSection');
    var tp = document.getElementById('tp_input'), em = document.getElementById('em_input');
    var lic = document.getElementById('lic_input'), car = document.getElementById('car_input'), plate = document.getElementById('plate_input');

    sSec.style.display = 'none'; 
    dSec.style.display = 'none';
    tp.required = em.required = lic.required = car.required = plate.required = false;

    if(role === 'student') {
        sSec.style.display = 'block';
        tp.required = em.required = true;
    } else if(role === 'driver') {
        dSec.style.display = 'block';
        lic.required = car.required = plate.required = true;
    }
}
</script>

</body>
</html>