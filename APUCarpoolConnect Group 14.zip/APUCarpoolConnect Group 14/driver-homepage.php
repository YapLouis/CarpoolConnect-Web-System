<?php
include 'db.php';
session_start();

//Security Check
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'driver') {
    header("Location: login.php");
    exit();
}

$driver_id = $_SESSION['user_id'];

//Join user_table with driver_detail_table to get car info AND rating
$driverQuery = "SELECT u.full_name, d.car_model, d.plate_number, d.driver_rating 
                FROM user_table u
                JOIN driver_detail_table d ON u.user_id = d.driver_id
                WHERE u.user_id = '$driver_id'";
$driverRes = mysqli_query($conn, $driverQuery);
$driverData = mysqli_fetch_assoc($driverRes);

//Fetch Active Scheduled Rides (Remains the same)
$ridesQuery = "SELECT r.*, lp.location_name as pickup, ld.location_name as dropoff 
               FROM rides_table r
               JOIN location_table lp ON r.pickup_id = lp.location_id
               JOIN location_table ld ON r.dropoff_id = ld.location_id
               WHERE r.driver_id = '$driver_id' AND r.ride_status = 'active'
               ORDER BY r.departure_time ASC";
$ridesRes = mysqli_query($conn, $ridesQuery);

//Calculate Earnings (Fares from carpool_request_table)
$earningsQuery = "SELECT SUM(fare) as total_earned FROM carpool_request_table rq
                  JOIN rides_table r ON rq.ride_id = r.ride_id
                  WHERE r.driver_id = '$driver_id' AND r.ride_status = 'completed' AND rq.status = 'approved'";
$earnRes = mysqli_query($conn, $earningsQuery);
$earned = mysqli_fetch_assoc($earnRes)['total_earned'] ?? 0;

//Total Completed Trips Count
$statsQuery = "SELECT COUNT(*) as total FROM rides_table WHERE driver_id = '$driver_id' AND ride_status = 'completed'";
$totalCompleted = mysqli_fetch_assoc(mysqli_query($conn, $statsQuery))['total'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Driver Dashboard - APU Carpool</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="driver.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body style="background: white !important; margin: 0;">

    <?php include 'driver-header.php'; ?>

    <div class="dashboard-container">
        <div style="margin-bottom: 30px;">
            <h1 style="color: #1e293b;">Welcome, <?= htmlspecialchars($_SESSION['full_name'] ?? 'Driver') ?></h1>
            <p style="color: #64748b;">Manage your vehicle and upcoming carpool schedules.</p>
        </div>

        <div class="vehicle-box" style="background: white; color: #1e293b; border-left: 5px solid #38bdf8; box-shadow: 0 4px 6px rgba(0,0,0,0.05); padding: 20px; border-radius: 12px;">
            <div style="display: flex; align-items: center; gap: 15px;">
                <i class="fas fa-car" style="font-size: 1.5rem; color: #38bdf8;"></i>
                <div>
                    <small style="color: #64748b; font-weight: bold; display: block;">REGISTERED VEHICLE</small>
                    <div style="font-weight: bold;">
                        <?= htmlspecialchars($driverData['car_model'] ?? 'No Car Registered') ?> 
                        — 
                        <?= htmlspecialchars($driverData['plate_number'] ?? 'No Plate') ?>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="stats-grid" style="margin-top: 20px;">
            <div class="stat-card">
                <h3>Rating</h3>
                <p style="color: #f1c40f;">
                    <i class="fas fa-star"></i> 
                    <?= number_format($driverData['driver_rating'] ?? 0, 1) ?>
                </p>
            </div>
            <div class="stat-card">
                <h3>Total Trips</h3>
                <p><?= $totalCompleted ?></p>
            </div>
        </div>

        <div class="ride-section" style="background: white; padding: 30px; border-radius: 15px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); margin-top: 30px;">
            <div class="ride-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; width: 1025px">
                <h2 style="margin:0; color: #1e293b;"><i class="fas fa-calendar-alt"></i> Upcoming Rides</h2>
                <a href="driver-create-ride.php" class="btn" style="background:#1e293b; color: white; padding: 10px 20px; text-decoration: none; border-radius: 8px; font-weight: bold;">+ Post Ride</a>
            </div>

            <?php if(mysqli_num_rows($ridesRes) > 0): ?>
                <?php while($ride = mysqli_fetch_assoc($ridesRes)): ?>
                    <div class="ride-item" style="border: 1px solid #edf2f7; padding: 15px; border-radius: 10px; margin-bottom: 10px; display: flex; justify-content: space-between; align-items: center;">
                        <div class="ride-info">
                            <h4 style="margin:0;"><?= $ride['pickup'] ?> <i class="fas fa-arrow-right" style="color:#38bdf8;"></i> <?= $ride['dropoff'] ?></h4>
                            <div class="ride-meta" style="color: #718096; font-size: 0.9rem;">
                                <span><i class="far fa-calendar"></i> <?= date('d M', strtotime($ride['departure_time'])) ?></span>
                                <span><i class="far fa-clock"></i> <?= date('h:i A', strtotime($ride['departure_time'])) ?></span>
                            </div>
                        </div>
                        <a href="driver-manage-request.php?ride_id=<?= $ride['ride_id'] ?>" class="btn" style="background: #38bdf8; color: white; padding: 8px 15px; text-decoration: none; border-radius: 5px; font-weight: 600;">Manage</a>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p style="text-align: center; color: #94a3b8; padding: 20px;">No active rides. Start by posting one!</p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>