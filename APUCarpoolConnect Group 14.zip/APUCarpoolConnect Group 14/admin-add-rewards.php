<?php
include 'db.php';
include 'admin-header.php';

//AUTO-GENERATE VOUCHER ID
$res_id = mysqli_query($conn, "SELECT voucher_id FROM voucher_list_table ORDER BY voucher_id DESC LIMIT 1");
if (mysqli_num_rows($res_id) > 0) {
    $last_id = mysqli_fetch_assoc($res_id)['voucher_id'];
    $num = (int)substr($last_id, 1) + 1; 
    $new_v_id = "V" . str_pad($num, 3, '0', STR_PAD_LEFT);
} else {
    $new_v_id = "V001";
}

//HANDLE CREATE
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $v_id = $_POST['voucher_id'];
    $name = mysqli_real_escape_string($conn, $_POST['voucher_name']);
    $points = (int)$_POST['point_cost'];
    $stock = (int)$_POST['stock_quantity'];
    $terms = mysqli_real_escape_string($conn, $_POST['terms_conditions']);
    $status = 1; 

    if (!empty($name)) {
        //Removed expiry_date from columns and values
        $sql = "INSERT INTO voucher_list_table (voucher_id, voucher_name, point_cost, stock_quantity, terms_conditions, voucher_status) 
                VALUES ('$v_id', '$name', $points, $stock, '$terms', $status)";
        
        if (mysqli_query($conn, $sql)) {
            echo "<script>alert('New reward added successfully!'); window.location.href='admin-rewards.php';</script>";
            exit();
        } else {
            $error_msg = "Database Error: " . mysqli_error($conn);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Reward - APU Carpool</title>
    <link rel="stylesheet" href="admin-style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body style="overflow: auto;">

<div class="main-content" style="display: block !important; padding-top: 20px !important;">
    <div class="content-wrapper" style="margin: auto; max-width: 95%;">
        
        <div style="text-align: center; margin-bottom: 20px; margin-top: 0px !important;">
            <h1 style="color: #003366; text-transform: uppercase; margin: 0; font-size: 2.2rem; font-weight: 800; letter-spacing: 1px;">Create New Voucher</h1>
            <p style="color: #888; font-size: 0.95rem; margin-top: 5px;">Register a new voucher for students to redeem using Eco-points</p>
        </div>

        <div class="add-user-container" style="max-width: 850px; margin: 0 auto; padding-bottom: 20px;">
            <form method="POST">
                
                <div class="form-section-title">
                    <i class="fas fa-gift"></i> Reward Details (Voucher ID: <?= $new_v_id ?>)
                </div>

                <div class="input-grid" style="margin-bottom: 0px !important;">
                    <div class="input-group">
                        <label>Voucher ID</label>
                        <input type="text" name="voucher_id" class="form-input" value="<?= $new_v_id ?>" readonly style="background: #f4f4f4; cursor: not-allowed; font-family: monospace; font-weight: bold; color: #555;">
                    </div>

                    <div class="input-group">
                        <label>Voucher Name</label>
                        <input type="text" name="voucher_name" class="form-input" placeholder="e.g., RM5 Cafeteria Meal Voucher" required autofocus>
                    </div>

                    <div class="input-group">
                        <label>Point Cost</label>
                        <input type="number" name="point_cost" class="form-input" placeholder="e.g., 500" required>
                    </div>

                    <div class="input-group">
                        <label>Stock Quantity</label>
                        <input type="number" name="stock_quantity" class="form-input" placeholder="e.g., 100" required>
                    </div>
                </div>

                <div class="input-group" style="margin-top: 15px;">
                    <label>Terms & Conditions</label>
                    <textarea name="terms_conditions" class="form-input" rows="4" 
                        placeholder="Enter voucher rules here..." 
                        style="width: 100%; border: 1px solid #ddd; border-radius: 8px; padding: 10px; font-family: inherit; resize: none;" required></textarea>
                </div>

                <div style="display: flex; flex-direction: column; align-items: center; margin-top: 0px;">
                    <button type="submit" class="btn-submit-user" style="width: 100%; margin-top: 20px !important;">SAVE REWARD</button>
                    <a href="admin-rewards.php" style="color: #999; text-decoration: none; font-size: 13px; font-weight: bold; text-transform: uppercase; letter-spacing: 1px; margin-top: 15px;">CANCEL</a>
                </div>
            </form>
        </div>
    </div>
</div>

</body>
</html>