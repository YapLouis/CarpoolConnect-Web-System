<?php
include 'db.php';
include 'admin-header.php';

//AUTO-GENERATE LOCATION ID
$res_id = mysqli_query($conn, "SELECT location_id FROM location_table ORDER BY location_id DESC LIMIT 1");
if (mysqli_num_rows($res_id) > 0) {
    $last_id = mysqli_fetch_assoc($res_id)['location_id'];
    $num = (int)substr($last_id, 1) + 1; 
    $new_loc_id = "L" . str_pad($num, 3, '0', STR_PAD_LEFT);
} else {
    $new_loc_id = "L001";
}

//HANDLE CREATE
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $loc_id = $_POST['location_id'];
    $loc_name = mysqli_real_escape_string($conn, $_POST['location_name']);
    $lat = mysqli_real_escape_string($conn, $_POST['latitude']);
    $lng = mysqli_real_escape_string($conn, $_POST['longitude']);
    
    //Automatically key in 'both' for location type
    $type = "both";

    if (!empty($loc_name)) {
        $sql = "INSERT INTO location_table (location_id, location_name, latitude, longitude, location_type) 
                VALUES ('$loc_id', '$loc_name', '$lat', '$lng', '$type')";
        
        if (mysqli_query($conn, $sql)) {
            echo "<script>alert('New location added successfully!'); window.location.href='admin-rides.php';</script>";
            exit();
        } else {
            $error_msg = "Database Error: " . mysqli_error($conn);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Location - APU Carpool</title>
    <link rel="stylesheet" href="admin-style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body style="overflow: auto;">

<div class="main-content" style="display: block !important; padding-top: 20px !important;">
    <div class="content-wrapper" style="margin: auto; max-width: 95%;">
        
        <div style="text-align: center; margin-bottom: 20px; margin-top: 0px !important;">
            <h1 style="color: #003366; text-transform: uppercase; margin: 0; font-size: 2.2rem; font-weight: 800; letter-spacing: 1px;">Create New Location</h1>
            <p style="color: #888; font-size: 0.95rem; margin-top: 5px;">Register a new pick-up or drop-off destination</p>
        </div>

        <div class="add-user-container" style="max-width: 850px; margin: 0 auto; padding-bottom: 20px;">
            <form method="POST">
                
                <div class="form-section-title">
                    <i class="fas fa-map-marked-alt"></i> Location Details (Location ID: <?= $new_loc_id ?>)
                </div>

                <div class="input-grid" style="margin-bottom: 0px !important;">
                    <div class="input-group">
                        <label>Location ID</label>
                        <input type="text" name="location_id" class="form-input" value="<?= $new_loc_id ?>" readonly style="background: #f4f4f4; cursor: not-allowed; font-family: monospace; font-weight: bold; color: #555;">
                    </div>

                    <div class="input-group">
                        <label>Location Name</label>
                        <input type="text" name="location_name" class="form-input" placeholder="e.g., APU Main Entrance" required autofocus>
                    </div>

                    <div class="input-group">
                        <label>Latitude</label>
                        <input type="text" name="latitude" class="form-input" placeholder="e.g., 3.0560" required>
                    </div>

                    <div class="input-group">
                        <label>Longitude</label>
                        <input type="text" name="longitude" class="form-input" placeholder="e.g., 101.7000" required>
                    </div>
                </div>

                <div style="display: flex; flex-direction: column; align-items: center; margin-top: 0px;">
                    <button type="submit" class="btn-submit-user" style="width: 100%; margin-top: 20px !important;">SAVE LOCATION</button>
                    <a href="admin-rides.php" style="color: #999; text-decoration: none; font-size: 13px; font-weight: bold; text-transform: uppercase; letter-spacing: 1px; margin-top: 15px;">CANCEL</a>
                </div>
            </form>
        </div>
    </div>
</div>

</body>
</html>