<?php
include 'db.php';
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'student') {
    header("Location: login.php"); 
    exit();
}

$request_id = isset($_GET['id']) ? mysqli_real_escape_string($conn, $_GET['id']) : '';

//Fetch Request and Ride Data from the database
$query = "SELECT rq.*, r.ride_id, r.departure_time, r.driver_id,
                 u.full_name as driver_name, u.phone_number,
                 dd.car_model, dd.plate_number,
                 lp.location_name as pickup_name, lp.latitude as p_lat, lp.longitude as p_lng,
                 ld.location_name as dropoff_name, ld.latitude as d_lat, ld.longitude as d_lng
          FROM carpool_request_table rq
          JOIN rides_table r ON rq.ride_id = r.ride_id
          JOIN user_table u ON r.driver_id = u.user_id
          JOIN driver_detail_table dd ON r.driver_id = dd.driver_id
          JOIN location_table lp ON r.pickup_id = lp.location_id
          JOIN location_table ld ON r.dropoff_id = ld.location_id
          WHERE rq.request_id = '$request_id'";

$result = mysqli_query($conn, $query);
$ride = mysqli_fetch_assoc($result);

if (!$ride) {
    die("Ride details not found. <a href='ride-history.php'>Go back</a>");
}

//Live Fare Calculation
$current_ride_id = $ride['ride_id'];
$countRes = mysqli_query($conn, "SELECT COUNT(*) as total FROM carpool_request_table WHERE ride_id = '$current_ride_id' AND status = 'approved'");
$countData = mysqli_fetch_assoc($countRes);
$approvedCount = $countData['total'];

//Use centralized functions for distance and total cost
$distance = getEstimatedRoadDist($ride['p_lat'], $ride['p_lng'], $ride['d_lat'], $ride['d_lng']);
$totalVehicleCost = calculateTotalFare($distance);

//Divide the total cost by the number of approved students
if ($approvedCount > 0) {
    $liveFare = $totalVehicleCost / $approvedCount;
} else {
    $liveFare = $totalVehicleCost;
}

$co2_saved = calculateCO2Saved($distance);
$eco_points = calculateEcoPoints($distance);

// Estimate Arrival (30km/h avg)
$travelTimeMinutes = ($distance / 30) * 60;
$departureTime = strtotime($ride['departure_time']);
$arrivalTime = $departureTime + ($travelTimeMinutes * 60);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ride Details - APU Carpool</title>
    <link rel="stylesheet" href="student.css">
    <style>
        .details-container { max-width: 600px; margin: 30px auto; background: white; border-radius: 20px; overflow: hidden; box-shadow: 0 10px 25px rgba(0,0,0,0.1); }
        .details-header { background: #28a745; color: white; padding: 30px; text-align: center; }
        .details-body { padding: 30px; }
        .info-row { display: flex; justify-content: space-between; margin-bottom: 15px; border-bottom: 1px #f4f4f4 solid; padding-bottom: 10px; }
        .payment-box { background: #fff9db; border: 1px solid #fab005; padding: 15px; border-radius: 10px; margin-top: 20px; }
        .driver-card { display: flex; align-items: center; background: #f8f9fa; padding: 15px; border-radius: 10px; margin-bottom: 20px; }
    </style>
</head>
<body>

    <?php include 'student-header.php'; ?>

    <div class="details-container">
        <div class="details-header">
            <h2 style="margin:0;">Ride Confirmed!</h2>
            <p>Your request <?= htmlspecialchars($ride['request_id']) ?> has been approved.</p>
        </div>

        <div class="details-body">
            <div class="driver-card">
                <div style="font-size: 2rem; margin-right: 15px;">🚗</div>
                <div>
                    <strong>Driver: <?= htmlspecialchars($ride['driver_name']) ?></strong><br>
                    <small>📞 Contact: <?= htmlspecialchars($ride['phone_number']) ?></small><br>
                    <small>🚘 <strong><?= htmlspecialchars($ride['car_model']) ?></strong> (<?= htmlspecialchars($ride['plate_number']) ?>)</small>
                </div>
            </div>

            <div class="info-row">
                <span>📍 <strong>Pickup:</strong></span>
                <span><?= htmlspecialchars($ride['pickup_name']) ?></span>
            </div>
            <div class="info-row">
                <span>🏁 <strong>Drop-off:</strong></span>
                <span><?= htmlspecialchars($ride['dropoff_name']) ?></span>
            </div>
            <div class="info-row">
                <span>🕒 <strong>Departure:</strong></span>
                <span><?= date('h:i A', $departureTime) ?></span>
            </div>
            <div class="info-row">
                <span>⌛ <strong>Est. Arrival:</strong></span>
                <span style="color: #28a745; font-weight: bold;"><?= date('h:i A', $arrivalTime) ?></span>
            </div>
            
            <div class="info-row">
                <span>💰 <strong>Total Fare:</strong></span>
                <span style="font-size: 1.2rem; color: #333; font-weight: bold;">RM <?= number_format($liveFare, 2) ?></span>
            </div>

            <div class="info-row" style="background: #e8f5e9; padding: 10px; border-radius: 8px; border: none;">
                <span>🌱 <strong>Carbon Saved:</strong></span>
                <span style="color: #2e7d32; font-weight: bold;"><?= number_format($co2_saved, 2) ?> kg CO2</span>
            </div>

            <div class="payment-box">
                <strong>💳 Payment Reminder:</strong>
                <p style="font-size: 0.9rem; margin-top: 5px;">Please prepare <strong>RM <?= number_format($liveFare, 2) ?></strong>. You can pay the driver via <strong>Cash</strong> or <strong>Touch 'n Go eWallet</strong> upon arrival.</p>
            </div>

            <button onclick="window.print()" class="btn student" style="width: 100%; margin-top: 20px; background: #333; color: white; border: none; padding: 12px; border-radius: 8px; cursor: pointer; font-weight: bold;">Print / Save Receipt</button>
            <a href="ride-history.php" style="display:block; text-align:center; margin-top:15px; color:#666; text-decoration: none;">Back to History</a>
        </div>
    </div>

</body>
</html>