<?php
if (session_status() === PHP_SESSION_NONE) session_start();

//Ensure only drivers access this header
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'driver') {
    header("Location: login.php");
    exit();
}

$driver_name = $_SESSION['full_name'] ?? "Driver";
$page = basename($_SERVER['PHP_SELF']);

//Function to handle active link styling
function isDriverPageActive($page, $targets) {
    return in_array($page, (array)$targets) ? 'active-driver-link' : '';
}
?>

<link rel="stylesheet" href="driver.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

<header class="driver-header">
    <div style="flex: 1;">
        <img src="apucarpoolconnectlogo-header.png" alt="APU Logo" style="height: 40px; filter: brightness(0) invert(1);">
    </div>

    <nav class="driver-nav">
        <a href="driver-homepage.php" class="driver-nav-link <?= isDriverPageActive($page, 'driver-homepage.php') ?>">
            <i class="fas fa-th-large"></i> Dashboard
        </a>

        <a href="driver-my-rides.php" class="driver-nav-link <?= isDriverPageActive($page, ['driver-my-rides.php', 'manage-rides.php', 'ride-details-driver.php']) ?>">
            <i class="fas fa-route"></i> My Rides
        </a>

        <a href="driver-create-ride.php" class="driver-nav-link <?= isDriverPageActive($page, 'driver-create-ride.php') ?>">
            <i class="fas fa-plus-circle"></i> Post Ride
        </a>

        <a href="driver-earning.php" class="driver-nav-link <?= isDriverPageActive($page, 'driver-earning.php') ?>">
            <i class="fas fa-wallet"></i> Earnings
        </a>
    </nav>

    <div class="driver-profile">
        <a href="driver-profile.php" style="display: flex; align-items: center; text-decoration: none; color: inherit; gap: 12px;">
            <div style="text-align: right; line-height: 1.2;">
                <div style="font-size: 0.85rem; font-weight: bold; color: white;"><?= htmlspecialchars($driver_name) ?></div>
                <span class="driver-status-indicator">My Profile</span>
            </div>
            <i class="fas fa-user-circle" style="font-size: 2.2rem; color: white;" title="View Profile"></i>
        </a>
    </div>
</header>

<script>
function confirmLogout() {
    if (confirm("Are you sure you want to logout?")) {
        window.location.href = "logout.php";
    }
}
</script>