<?php
include 'db.php';
header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);

if (!$data) {
    echo json_encode(['success' => false, 'message' => 'No data received']);
    exit;
}

$rid = mysqli_real_escape_string($conn, $data['ride_id']);
$status = mysqli_real_escape_string($conn, $data['ride_status']);

$sql = "UPDATE rides_table SET ride_status='$status' WHERE ride_id='$rid'";

if (mysqli_query($conn, $sql)) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'message' => mysqli_error($conn)]);
}
?>