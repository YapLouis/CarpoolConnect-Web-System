<?php
include 'db.php';
session_start();

//Security Check
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'driver') {
    header("Location: login.php");
    exit(); 
}

$driver_id = $_SESSION['user_id'];
$status_msg = ""; 

//Check for the success message in the URL
if (isset($_GET['msg'])) {
    if ($_GET['msg'] == 'success') {
        $co2 = $_GET['co2'] ?? '0.00';
        $status_msg = "<div class='alert success'>Ride completed! You saved " . htmlspecialchars($co2) . "kg of CO2!</div>";
    } elseif ($_GET['msg'] == 'cancelled') {
        $status_msg = "<div class='alert danger'>Ride has been cancelled.</div>";
    }
}

//Haversine Formula to calculate distance between two coordinates
function getDist($lat1, $lon1, $lat2, $lon2) {
    $earth_radius = 6371; //Earth radius in Kilometers
    $dLat = deg2rad($lat2 - $lat1);
    $dLon = deg2rad($lon2 - $lon1);
    
    $a = sin($dLat/2) * sin($dLat/2) + 
         cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * sin($dLon/2) * sin($dLon/2);
         
    $c = 2 * atan2(sqrt($a), sqrt(1-$a));
    return $earth_radius * $c;
}

//Handle Status Updates
if (isset($_GET['action']) && isset($_GET['ride_id'])) {
    $action = $_GET['action'];
    $r_id = mysqli_real_escape_string($conn, $_GET['ride_id']);
    
    if ($action == 'complete') {
        //First, check if this ride is already completed
        $checkQuery = "SELECT ride_status FROM rides_table WHERE ride_id = '$r_id'";
        $checkRes = mysqli_query($conn, $checkQuery);
        $currentStatus = mysqli_fetch_assoc($checkRes)['ride_status'] ?? '';

        if ($currentStatus === 'active') {
            //Fetch Coordinates for Carbon Calculation
            $distQuery = "SELECT lp.latitude as p_lat, lp.longitude as p_lng, 
                                 ld.latitude as d_lat, ld.longitude as d_lng 
                          FROM rides_table r
                          JOIN location_table lp ON r.pickup_id = lp.location_id
                          JOIN location_table ld ON r.dropoff_id = ld.location_id
                          WHERE r.ride_id = '$r_id'";
            
            $res = mysqli_query($conn, $distQuery);
            if ($loc = mysqli_fetch_assoc($res)) {
                $distance = getDist($loc['p_lat'], $loc['p_lng'], $loc['d_lat'], $loc['d_lng']);
                $co2_saved = $distance * 0.2;
                $points_to_award = round($co2_saved * 100); 

                //Generate Carbon ID (C00X)
                $idRes = mysqli_query($conn, "SELECT carbon_id FROM carbon_tracking_table ORDER BY carbon_id DESC LIMIT 1");
                $newCarbonID = "C001";
                if (mysqli_num_rows($idRes) > 0) {
                    $lastID = mysqli_fetch_assoc($idRes)['carbon_id'];
                    $num = (int)substr($lastID, 1) + 1;
                    $newCarbonID = "C" . str_pad($num, 3, "0", STR_PAD_LEFT);
                }
                mysqli_query($conn, "INSERT INTO carbon_tracking_table (carbon_id, ride_id, distance, co2_saved) VALUES ('$newCarbonID', '$r_id', '$distance', '$co2_saved')");

                //Award points to all Approved Passengers
                $passengerQuery = "SELECT student_id FROM carpool_request_table WHERE ride_id = '$r_id' AND status = 'approved'";
                $passengers = mysqli_query($conn, $passengerQuery);
                
                while($p_row = mysqli_fetch_assoc($passengers)) {
                    $p_id = $p_row['student_id'];
                    
                    //Generate Points ID (P00X)
                    $pIdRes = mysqli_query($conn, "SELECT points_id FROM eco_points_table ORDER BY points_id DESC LIMIT 1");
                    $newPointsID = "P001";
                    if (mysqli_num_rows($pIdRes) > 0) {
                        $lastPID = mysqli_fetch_assoc($pIdRes)['points_id'];
                        $pNum = (int)substr($lastPID, 1) + 1;
                        $newPointsID = "P" . str_pad($pNum, 3, "0", STR_PAD_LEFT);
                    }

                    //Insert Point Transaction
                    mysqli_query($conn, "INSERT INTO eco_points_table (points_id, user_id, ride_id, points_earned, earned_at) 
                                         VALUES ('$newPointsID', '$p_id', '$r_id', '$points_to_award', NOW())");
                    
                    //Update Student's Total Balance
                    mysqli_query($conn, "UPDATE student_details_table SET total_points = total_points + $points_to_award WHERE student_id = '$p_id'");
                }

                //Final Ride Status Update
                $update = "UPDATE rides_table SET ride_status = 'completed' WHERE ride_id = '$r_id' AND driver_id = '$driver_id'";
                
                if (mysqli_query($conn, $update)) {
                    header("Location: driver-my-rides.php?msg=success&co2=" . number_format($co2_saved, 2));
                    exit();
                }
            }
        }
    } elseif ($action == 'cancel') {
        $update = "UPDATE rides_table SET ride_status = 'cancelled' WHERE ride_id = '$r_id' AND driver_id = '$driver_id'";
        if (mysqli_query($conn, $update)) {
            header("Location: driver-my-rides.php?msg=cancelled");
            exit();
        }
    }
}

//Fetch Active Rides
$activeQuery = "SELECT r.*, lp.location_name as pickup, ld.location_name as dropoff 
                FROM rides_table r
                JOIN location_table lp ON r.pickup_id = lp.location_id
                JOIN location_table ld ON r.dropoff_id = ld.location_id
                WHERE r.driver_id = '$driver_id' AND r.ride_status = 'active'
                ORDER BY r.departure_time ASC";
$activeRides = mysqli_query($conn, $activeQuery);

//Fetch Ride History
$historyQuery = "SELECT r.*, lp.location_name as pickup, ld.location_name as dropoff 
                 FROM rides_table r
                 JOIN location_table lp ON r.pickup_id = lp.location_id
                 JOIN location_table ld ON r.dropoff_id = ld.location_id
                 WHERE r.driver_id = '$driver_id' AND r.ride_status != 'active'
                 ORDER BY r.departure_time DESC";
$historyRides = mysqli_query($conn, $historyQuery);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Rides - APU Carpool</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="driver.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .alert { padding: 15px; border-radius: 8px; margin-bottom: 20px; font-weight: bold; }
        .alert.success { background: #dcfce7; color: #166534; }
        .alert.danger { background: #fee2e2; color: #991b1b; }
        .badge { padding: 4px 10px; border-radius: 5px; font-size: 0.8rem; text-transform: uppercase; }
        .bg-completed { background: #dcfce7; color: #166534; }
        .bg-cancelled { background: #fee2e2; color: #991b1b; }
    </style>
</head>
<body style="background: white !important; margin: 0;">

    <?php include 'driver-header.php'; ?>

    <div class="dashboard-container">
        <div class="ride-header">
            <h1><i class="fas fa-route" style="color: #38bdf8;"></i> Manage My Rides</h1>
            <a href="driver-create-ride.php" class="btn" style="background:#1e293b; color:white; text-decoration:none; padding:10px 20px; border-radius:8px;">+ New Ride</a>
        </div>

        <?= $status_msg ?>

        <h3 style="margin-top: 30px; color: #1e293b;">Active / Upcoming</h3>
        <div class="ride-section" style="margin-bottom: 40px;">
            <?php if(mysqli_num_rows($activeRides) > 0): ?>
                <?php while($row = mysqli_fetch_assoc($activeRides)): ?>
                    <div class="ride-item">
                        <div class="ride-info">
                            <h4><?= $row['pickup'] ?> ➔ <?= $row['dropoff'] ?></h4>
                            <div class="ride-meta">
                                <span><i class="far fa-calendar"></i> <?= date('d M Y', strtotime($row['departure_time'])) ?></span>
                                <span><i class="far fa-clock"></i> <?= date('h:i A', strtotime($row['departure_time'])) ?></span>
                                <span><i class="fas fa-chair"></i> <?= $row['total_seats'] ?> seats</span>
                            </div>
                        </div>
                        <div style="display: flex; gap: 10px;">
                            <a href="driver-manage-request.php?ride_id=<?= $row['ride_id'] ?>" class="btn" style="background:#38bdf8; color:white; text-decoration:none; padding:8px 15px; border-radius:5px; font-size:0.8rem;">Requests</a>
                            <a href="driver-my-rides.php?action=complete&ride_id=<?= $row['ride_id'] ?>" onclick="return confirm('Mark this ride as completed?')" class="btn" style="background:#22c55e; color:white; text-decoration:none; padding:8px 15px; border-radius:5px; font-size:0.8rem;">Complete</a>
                            <a href="driver-my-rides.php?action=cancel&ride_id=<?= $row['ride_id'] ?>" onclick="return confirm('Are you sure you want to cancel?')" class="btn" style="background:#ef4444; color:white; text-decoration:none; padding:8px 15px; border-radius:5px; font-size:0.8rem;">Cancel</a>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p style="color: #64748b; text-align: center; padding: 20px;">No active rides scheduled.</p>
            <?php endif; ?>
        </div>

        <h3 style="color: #1e293b;">Ride History</h3>
        <div class="ride-section">
            <?php if(mysqli_num_rows($historyRides) > 0): ?>
                <?php while($row = mysqli_fetch_assoc($historyRides)): ?>
                    <div class="ride-item" style="opacity: 0.8;">
                        <div class="ride-info">
                            <h4><?= $row['pickup'] ?> ➔ <?= $row['dropoff'] ?></h4>
                            <p style="font-size: 0.85rem; color: #64748b; margin: 5px 0;">
                                <?= date('d M Y, h:i A', strtotime($row['departure_time'])) ?>
                            </p>
                        </div>
                        <div>
                            <span class="badge bg-<?= $row['ride_status'] ?>"><?= $row['ride_status'] ?></span>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p style="color: #64748b; text-align: center; padding: 20px;">No ride history found.</p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>