<?php
include 'db.php';
session_start();

//Ensure only drivers access this page
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'driver') {
    header("Location: login.php"); exit();
}

$driver_id = $_SESSION['user_id'];
$message = "";

//Handle Profile Update
if (isset($_POST['update_profile'])) {
    $fullname = mysqli_real_escape_string($conn, $_POST['full_name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone_number']);
    $new_password = $_POST['new_password'];

    mysqli_begin_transaction($conn);

    try {
        $updateUser = "UPDATE user_table SET 
                       full_name = '$fullname', 
                       email = '$email', 
                       phone_number = '$phone' 
                       WHERE user_id = '$driver_id'";
        mysqli_query($conn, $updateUser);

        if (!empty($new_password)) {
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            $hashed_password = mysqli_real_escape_string($conn, $hashed_password);
            mysqli_query($conn, "UPDATE user_table SET password = '$hashed_password' WHERE user_id = '$driver_id'");
        }

        mysqli_commit($conn);
        header("Location: driver-profile.php?status=success");
        exit();
    } catch (Exception $e) {
        mysqli_rollback($conn);
        header("Location: driver-profile.php?status=error");
        exit();
    }
}

//Handle Status Messages
if (isset($_GET['status'])) {
    if ($_GET['status'] == 'success') {
        $message = "<div class='status-badge status-online' style='display:block; text-align:center; margin-bottom:20px;'>Profile updated successfully!</div>";
    } else {
        $message = "<div class='status-badge status-offline' style='display:block; text-align:center; margin-bottom:20px;'>Update failed. Please try again.</div>";
    }
}

//Fetch Current Data
$query = "SELECT u.*, d.license_number, d.car_model, d.plate_number, d.driver_rating 
          FROM user_table u 
          JOIN driver_detail_table d ON u.user_id = d.driver_id 
          WHERE u.user_id = '$driver_id'";
$res = mysqli_query($conn, $query);
$user = mysqli_fetch_assoc($res);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Driver Profile - APU Carpool</title>
    <link rel="stylesheet" href="driver.css">
    <style>
        .editable:disabled { 
            background-color: #f1f5f9 !important; 
            color: #64748b !important; 
            cursor: not-allowed; 
        }
        
        .btn-toggle-edit { 
            background: #38bdf8; 
            color: white; 
            padding: 10px 20px; 
            border-radius: 8px; 
            border: none; 
            cursor: pointer; 
            font-weight: 600;
        }

        .btn-save-edit { 
            display: none; 
            background: #059669; 
            color: white; 
            padding: 10px 20px; 
            border-radius: 8px; 
            border: none; 
            cursor: pointer; 
            font-weight: 600;
        }

        .btn-logout-alt {
            background: #e11d48;
            color: white;
            padding: 10px 20px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 600;
            font-size: 0.9rem;
        }
    </style>
</head>
<body>
    <?php include 'driver-header.php'; ?>

    <div class="dashboard-container">
        <div class="ride-section">
            <div class="ride-header">
                <h2 style="margin:0; color: #1e293b;">👤 My Profile</h2>
            </div>

            <?= $message ?>

            <div class="stats-grid">
                <div class="stat-card" style="text-align: left;">
                    <h3>Driver ID</h3>
                    <p style="font-size: 1.2rem; margin-top: 10px;"><?= $user['user_id'] ?></p>
                </div>
                <div class="stat-card" style="text-align: left;">
                    <h3>License Number</h3>
                    <p style="font-size: 1.2rem; margin-top: 10px;"><?= htmlspecialchars($user['license_number']) ?></p>
                </div>
            </div>

            <div class="vehicle-box">
                <div style="flex: 1;">
                    <strong>Vehicle:</strong> <?= htmlspecialchars($user['car_model']) ?> (<?= htmlspecialchars($user['plate_number']) ?>)
                </div>
                <div class="status-badge status-online">
                    ⭐ <?= number_format($user['driver_rating'], 1) ?> Rating
                </div>
            </div>

            <hr style="border:0; border-top:1px solid #f1f5f9; margin: 30px 0;">

            <form id="profileForm" method="POST" action="">
                <div class="form-group">
                    <label>Full Name</label>
                    <input type="text" name="full_name" class="editable" value="<?= htmlspecialchars($user['full_name']) ?>" required disabled>
                </div>

                <div class="form-group">
                    <label>Email Address</label>
                    <input type="email" name="email" class="editable" value="<?= htmlspecialchars($user['email']) ?>" required disabled>
                </div>

                <div class="form-group">
                    <label>Phone Number</label>
                    <input type="text" name="phone_number" class="editable" value="<?= htmlspecialchars($user['phone_number']) ?>" required disabled>
                </div>

                <div class="form-group">
                    <label>New Password (Leave blank to keep current)</label>
                    <input type="password" name="new_password" class="editable" placeholder="••••••••" disabled>
                </div>

                <div style="display: flex; gap: 15px; margin-top: 30px; align-items: center;">
                    <button type="button" id="toggleBtn" class="btn-toggle-edit" onclick="toggleEdit()">✏️ Edit Profile</button>
                    <button type="submit" name="update_profile" id="saveBtn" class="btn-save-edit">💾 Save Changes</button>
                    <a href="logout.php" class="btn-logout-alt" onclick="return confirm('Logout?')">🚪 Logout</a>
                </div>
            </form>
        </div>
    </div>

    <script>
    let isEditing = false;

    function toggleEdit() {
        isEditing = !isEditing; 
        const inputs = document.querySelectorAll('.editable');
        const toggleBtn = document.getElementById('toggleBtn');
        const saveBtn = document.getElementById('saveBtn');

        if (isEditing) {
            inputs.forEach(input => input.disabled = false);
            toggleBtn.innerHTML = "✖ Cancel";
            toggleBtn.style.background = "#64748b";
            saveBtn.style.display = "block";
            inputs[0].focus(); 
        } else {    
            inputs.forEach(input => {
                input.value = input.defaultValue;
                input.disabled = true;
            });
            toggleBtn.innerHTML = "✏️ Edit Profile";
            toggleBtn.style.background = "#38bdf8";
            saveBtn.style.display = "none";
        }
    }
    </script>
</body>
</html>