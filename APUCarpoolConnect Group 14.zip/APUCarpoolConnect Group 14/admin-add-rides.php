<?php
include 'db.php';
include 'admin-header.php';

//AUTO-GENERATE RIDE ID
$res_id = mysqli_query($conn, "SELECT ride_id FROM rides_table ORDER BY ride_id DESC LIMIT 1");
if (mysqli_num_rows($res_id) > 0) {
    $last_id = mysqli_fetch_assoc($res_id)['ride_id'];
    $num = (int)substr($last_id, 1) + 1; 
    $new_ride_id = "R" . str_pad($num, 3, '0', STR_PAD_LEFT);
} else {
    $new_ride_id = "R001";
}

//HANDLE CREATE
if(isset($_POST['add_ride'])){
    $rid = $_POST['ride_id'];
    $did = mysqli_real_escape_string($conn, $_POST['driver_id']);
    $p_id = mysqli_real_escape_string($conn, $_POST['pickup_id']);
    $d_id = mysqli_real_escape_string($conn, $_POST['dropoff_id']);
    $r_time = mysqli_real_escape_string($conn, $_POST['departure_time']);
    $seats = mysqli_real_escape_string($conn, $_POST['total_seats']);

    $sql = "INSERT INTO rides_table (ride_id, driver_id, pickup_id, dropoff_id, departure_time, total_seats, ride_status) 
            VALUES ('$rid', '$did', '$p_id', '$d_id', '$r_time', '$seats', 'active')";
    
    if(mysqli_query($conn, $sql)){
        echo "<script>alert('Ride Created Successfully!'); window.location.href='admin-rides.php';</script>";
    }
}

$drivers = mysqli_query($conn, "SELECT user_id, full_name FROM user_table WHERE role='driver'");
$locations = mysqli_query($conn, "SELECT * FROM location_table");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Ride - APU Carpool</title>
    <link rel="stylesheet" href="admin-style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body style="overflow: auto;">

<div class="main-content" style="display: block !important; padding-top: 20px !important;">
    <div class="content-wrapper" style="margin: auto; max-width: 95%;">
        
        <div style="text-align: center; margin-bottom: 20px; margin-top: 0px !important;">
            <h1 style="color: #003366; text-transform: uppercase; margin: 0; font-size: 2.2rem; font-weight: 800; letter-spacing: 1px;">Create New Ride</h1>
            <p style="color: #888; font-size: 0.95rem; margin-top: 5px;">Fill in the details to publish a new carpool schedule</p>
        </div>

        <div class="add-user-container" style="max-width: 850px; margin: 0 auto; padding-bottom: 20px;">
            <form method="POST">
                <input type="hidden" name="ride_id" value="<?= $new_ride_id ?>">
                
                <div class="form-section-title">
                    <i class="fas fa-car-side"></i> Trip Information (Ride ID: <?= $new_ride_id ?>)
                </div>

                <div class="input-grid" style="margin-bottom: 0px !important;">
                    <div class="input-group">
                        <label>Assigned Driver</label>
                        <select name="driver_id" class="form-input" required>
                            <option value="" disabled selected>-- Select Driver --</option>
                            <?php while($d = mysqli_fetch_assoc($drivers)) echo "<option value='{$d['user_id']}'>{$d['full_name']}</option>"; ?>
                        </select>
                    </div>

                    <div class="input-group">
                        <label>Departure Date & Time</label>
                        <input type="datetime-local" name="departure_time" class="form-input" required>
                    </div>

                    <div class="input-group">
                        <label>Pickup Location</label>
                        <select name="pickup_id" class="form-input" required>
                            <option value="" disabled selected>-- Select Pickup --</option>
                            <?php while($l = mysqli_fetch_assoc($locations)) echo "<option value='{$l['location_id']}'>{$l['location_name']}</option>"; ?>
                        </select>
                    </div>

                    <div class="input-group">
                        <label>Dropoff Location</label>
                        <select name="dropoff_id" class="form-input" required>
                            <option value="" disabled selected>-- Select Destination --</option>
                            <?php mysqli_data_seek($locations, 0); while($l = mysqli_fetch_assoc($locations)) echo "<option value='{$l['location_id']}'>{$l['location_name']}</option>"; ?>
                        </select>
                    </div>

                    <div class="input-group">
                        <label>Available Seats</label>
                        <input type="number" name="total_seats" class="form-input" min="1" max="10" value="4" required>
                    </div>

                    <div class="input-group">
                        <label>Initial Status</label>
                        <select name="ride_status" class="form-input">
                            <option value="active">Active</option>
                            <option value="pending">Pending</option>
                        </select>
                    </div>
                </div>

                <div style="display: flex; flex-direction: column; align-items: center; margin-top: 0px;">
                    <button type="submit" name="add_ride" class="btn-submit-user" style="width: 100%; margin-top: 20px !important;">PUBLISH RIDE</button>
                    <a href="admin-rides.php" style="color: #999; text-decoration: none; font-size: 13px; font-weight: bold; text-transform: uppercase; letter-spacing: 1px; margin-top: 15px;">CANCEL</a>
                </div>
            </form>
        </div>
    </div>
</div>

</body>
</html>