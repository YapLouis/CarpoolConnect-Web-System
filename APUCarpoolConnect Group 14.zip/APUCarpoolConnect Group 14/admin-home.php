<?php
    include 'db.php';
    include 'admin-header.php';

    //Stats Fetching
    $userCount = mysqli_num_rows(mysqli_query($conn, "SELECT 1 FROM user_table"));
    $rideCount = mysqli_num_rows(mysqli_query($conn, "SELECT 1 FROM rides_table WHERE ride_status='active'"));
    $carbon = mysqli_fetch_assoc(mysqli_query($conn, "SELECT SUM(co2_saved) as total FROM carbon_tracking_table"));
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - APU Carpool</title>
    <link rel="stylesheet" href="admin-style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>

    <div class="main-content">
        <div class="content-wrapper">
            <div class="welcome-text">
                <h1>Dashboard Overview</h1>
                <p>Welcome back, Administrator</p>
            </div>
            
            <div class="stats-row">
                <div class="stat-card">
                    <h2><?= $userCount; ?></h2>
                    <p>Total Users</p>
                </div>
                <div class="stat-card">
                    <h2><?= $rideCount; ?></h2>
                    <p>Active Rides</p>
                </div>
                <div class="stat-card">
                    <h2><?= number_format($carbon['total'] ?? 0, 1); ?>KG</h2>
                    <p>CO2 Reduced</p>
                </div>
            </div>

            <p style="text-align: center; color: #bbb; margin-top: 40px; font-size: 0.8rem; letter-spacing: 2px;">
                SYSTEM OPERATIONAL • NO ISSUES DETECTED
            </p>
        </div>
    </div>

</body>
</html>