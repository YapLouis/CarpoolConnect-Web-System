<?php
include 'db.php';
include 'admin-header.php';

//HANDLE DELETE RIDE
if(isset($_GET['delete_ride_id'])){
    $id = mysqli_real_escape_string($conn, $_GET['delete_ride_id']);
    mysqli_query($conn, "DELETE FROM rides_table WHERE ride_id = '$id'");
    header("Location: admin-rides.php?tab=rides");
    exit();
}

//HANDLE DELETE LOCATION
if(isset($_GET['delete_loc_id'])){
    $id = mysqli_real_escape_string($conn, $_GET['delete_loc_id']);
    mysqli_query($conn, "DELETE FROM location_table WHERE location_id = '$id'");
    header("Location: admin-rides.php?tab=locations");
    exit();
}

//FETCH RIDES
$rides_query = "SELECT r.*, u.full_name as driver_name, p.location_name as pickup, d.location_name as dropoff 
                FROM rides_table r 
                LEFT JOIN user_table u ON r.driver_id = u.user_id 
                LEFT JOIN location_table p ON r.pickup_id = p.location_id 
                LEFT JOIN location_table d ON r.dropoff_id = d.location_id 
                ORDER BY r.departure_time DESC";
$rides = mysqli_query($conn, $rides_query);

//FETCH LOCATIONS
$locations = mysqli_query($conn, "SELECT * FROM location_table ORDER BY location_name ASC");

//Determine which tab to show on reload
$activeTab = isset($_GET['tab']) ? $_GET['tab'] : 'rides';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Management - APU Carpool</title>
    <link rel="stylesheet" href="admin-style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body style="overflow: auto;">

<div class="main-content" style="display: block; padding-top: 100px;">
    <div class="content-wrapper" style="margin: auto; max-width: 95%;">
        
        <div style="margin-bottom: 30px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 20px;">
            <div>
                <h1 style="color: #003366; text-transform: uppercase; margin: 0;">Ride & Location Management</h1>
                <p style="color: #888; margin: 5px 0 0; font-size: 0.85rem;">Manage carpool schedules and campus destinations</p>
            </div>
            
            <div style="display: flex; gap: 20px; align-items: center;">
                <div class="role-toggle">
                    <button class="toggle-btn <?= $activeTab == 'rides' ? 'active' : '' ?>" onclick="showTab('rides-tab', this)">
                        <i class="fas fa-car"></i> View Rides
                    </button>
                    <button class="toggle-btn <?= $activeTab == 'locations' ? 'active' : '' ?>" onclick="showTab('locations-tab', this)">
                        <i class="fas fa-map-marker-alt"></i> View Locations
                    </button>
                </div>
                
                <a href="admin-add-rides.php" id="add-ride-btn" class="btn-add" style="display: <?= $activeTab == 'rides' ? 'inline-block' : 'none' ?>;">
                    <i class="fas fa-plus-circle"></i> Create Ride
                </a>
                <a href="admin-add-location.php" id="add-loc-btn" class="btn-add" style="display: <?= $activeTab == 'locations' ? 'inline-block' : 'none' ?>;">
                    <i class="fas fa-plus-circle"></i> Create    Location
                </a>
            </div>
        </div>

        <div id="rides-tab" class="tab-content" style="display: <?= $activeTab == 'rides' ? 'block' : 'none' ?>;">
            <div class="table-container" style="overflow-x: auto;">
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>Ride ID</th>
                            <th>Driver</th>
                            <th>Route</th>
                            <th>Departure Time</th>
                            <th>Seats</th>
                            <th>Status</th>
                            <th style="text-align: center;">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($row = mysqli_fetch_assoc($rides)): ?>
                        <tr>
                            <td><code><?= $row['ride_id'] ?></code></td>
                            <td><strong><?= $row['driver_name'] ?></strong></td>
                            <td>
                                <div style="font-size: 0.85rem;"><?= $row['pickup'] ?></div>
                                <div style="font-size: 0.75rem; color: #999;"><i class="fas fa-arrow-right"></i> <?= $row['dropoff'] ?></div>
                            </td>
                            <td><?= date('d M, h:i A', strtotime($row['departure_time'])) ?></td>
                            <td><?= $row['total_seats'] ?></td>
                            <td>
                                <select class="inline-input" onchange="updateStatus('<?= $row['ride_id'] ?>', this.value)" style="width: auto; border: 1px solid #ddd; border-radius: 4px; padding: 2px 5px;">
                                    <option value="active" <?= $row['ride_status'] == 'active' ? 'selected' : '' ?>>Active</option>
                                    <option value="completed" <?= $row['ride_status'] == 'completed' ? 'selected' : '' ?>>Completed</option>
                                    <option value="cancelled" <?= $row['ride_status'] == 'cancelled' ? 'selected' : '' ?>>Cancelled</option>
                                </select>
                            </td>
                            <td style="text-align: center;">
                                <a href="admin-rides.php?delete_ride_id=<?= $row['ride_id'] ?>" class="btn-action btn-delete" onclick="return confirm('Delete this ride?')">
                                    <i class="fas fa-trash-alt"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div id="locations-tab" class="tab-content" style="display: <?= $activeTab == 'locations' ? 'block' : 'none' ?>;">
            <div class="table-container" style="overflow-x: auto;">
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>Location ID</th>
                            <th>Name</th>
                            <th>Latitude</th>
                            <th>Longitude</th>
                            <th>Type</th>
                            <th style="text-align: center;">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($loc = mysqli_fetch_assoc($locations)): ?>
                        <tr id="loc-row-<?= $loc['location_id'] ?>">
                            <td><code><?= $loc['location_id'] ?></code></td>
                            <td>
                                <input type="text" name="location_name" class="inline-input" 
                                    value="<?= $loc['location_name'] ?>" readonly 
                                    oninput="locChanged('<?= $loc['location_id'] ?>')" style="font-weight: bold;">
                            </td>
                            <td>
                                <input type="text" name="latitude" class="inline-input" 
                                    value="<?= $loc['latitude'] ?>" readonly 
                                    oninput="locChanged('<?= $loc['location_id'] ?>')">
                            </td>
                            <td>
                                <input type="text" name="longitude" class="inline-input" 
                                    value="<?= $loc['longitude'] ?>" readonly 
                                    oninput="locChanged('<?= $loc['location_id'] ?>')">
                            </td>
                            <td><span class="role-badge" style="background: #e1f5fe; color: #0288d1;"><?= strtoupper($loc['location_type']) ?></span></td>
                            <td style="text-align: center; white-space: nowrap;">
                                <button class="btn-action btn-edit" id="btn-edit-loc-<?= $loc['location_id'] ?>" onclick="enableLocRow('<?= $loc['location_id'] ?>')">
                                    <i class="fas fa-edit"></i>
                                </button>
                                
                                <button class="btn-action btn-confirm" id="btn-save-loc-<?= $loc['location_id'] ?>" style="display:none;" onclick="updateLocation('<?= $loc['location_id'] ?>')">
                                    <i class="fas fa-check"></i>
                                </button>

                                <a href="admin-rides.php?delete_loc_id=<?= $loc['location_id'] ?>" class="btn-action btn-delete" onclick="return confirm('Delete this location?')">
                                    <i class="fas fa-trash-alt"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</div>

<script>
function showTab(tabId, btn) {
    //Hide all contents
    document.getElementById('rides-tab').style.display = 'none';
    document.getElementById('locations-tab').style.display = 'none';
    
    //Hide/Show correct Add buttons
    document.getElementById('add-ride-btn').style.display = (tabId === 'rides-tab') ? 'inline-block' : 'none';
    document.getElementById('add-loc-btn').style.display = (tabId === 'locations-tab') ? 'inline-block' : 'none';

    //Toggle active class on buttons
    document.querySelectorAll('.toggle-btn').forEach(b => b.classList.remove('active'));
    
    //Show selected content
    document.getElementById(tabId).style.display = 'block';
    btn.classList.add('active');
}

function updateStatus(rideId, newStatus) {
    fetch('admin-update-rides.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ride_id: rideId, ride_status: newStatus })
    })
    .then(r => r.json())
    .then(data => {
        if(data.success) { alert("Status Updated!"); }
        else { alert("Error: " + data.message); location.reload(); }
    });
}

function enableLocRow(locId) {
    const inputs = document.querySelectorAll(`#loc-row-${locId} input`);
    const isReadOnly = inputs[0].readOnly;
    inputs.forEach(input => input.readOnly = !isReadOnly);
    if (isReadOnly) inputs[0].focus();
}

function locChanged(locId) {
    document.getElementById('btn-edit-loc-' + locId).style.display = 'none';
    document.getElementById('btn-save-loc-' + locId).style.display = 'inline-flex';
}

function updateLocation(locId) {
    const row = document.getElementById('loc-row-' + locId);
    const inputs = row.querySelectorAll('input');
    let formData = { location_id: locId };
    inputs.forEach(input => formData[input.name] = input.value);

    fetch('admin-update-location.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
    })
    .then(r => r.json())
    .then(data => {
        if(data.success) { 
            alert("Location updated successfully!"); 
            location.reload(); 
        } else { 
            alert("Error: " + data.message); 
        }
    });
}

</script>

</body>
</html>