<?php
include 'db.php';
session_start();

//Security Check
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'student') {
    header("Location: login.php");
    exit();
}

//Get Data from URL
$ride_id = isset($_GET['id']) ? mysqli_real_escape_string($conn, $_GET['id']) : '';
$fare = isset($_GET['fare']) ? floatval($_GET['fare']) : 0;
$student_id = $_SESSION['user_id']; 

if (empty($ride_id) || $fare <= 0) {
    die("Invalid request or fare amount. <a href='student-homepage.php'>Go back</a>");
}

//Generate the Custom Request ID (REQ001, REQ002...)
$idRes = mysqli_query($conn, "SELECT request_id FROM carpool_request_table ORDER BY request_id DESC LIMIT 1");

if (mysqli_num_rows($idRes) > 0) {
    $row = mysqli_fetch_assoc($idRes);
    $lastID = $row['request_id']; 
    
    //Change substr($lastID, 1) to substr($lastID, 3) because "REQ" is 3 characters
    $num = (int)substr($lastID, 3); 
    
    $newID = "REQ" . str_pad($num + 1, 3, "0", STR_PAD_LEFT);
} else {
    $newID = "REQ001";
}

//Check for duplicates (Student shouldn't join same ride twice)
$dupCheck = mysqli_query($conn, "SELECT * FROM carpool_request_table WHERE ride_id = '$ride_id' AND student_id = '$student_id'");
if (mysqli_num_rows($dupCheck) > 0) {
    echo "<script>alert('You already requested this ride!'); window.location.href='student-homepage.php';</script>";
    exit();
}

//Insert Request including the Fare
$query = "INSERT INTO carpool_request_table (request_id, ride_id, student_id, fare, status) 
          VALUES ('$newID', '$ride_id', '$student_id', '$fare', 'pending')";

if (mysqli_query($conn, $query)) {
    $success_msg = "Request Sent Successfully! Fare of RM " . number_format($fare, 2) . " recorded.";
} else {
    die("Database Error: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Request Status - APU Carpool</title>
    <link rel="stylesheet" href="student.css">
    <style>
        .status-card { max-width: 500px; margin: 100px auto; background: white; padding: 40px; border-radius: 20px; text-align: center; box-shadow: 0 10px 30px rgba(0,0,0,0.1); }
        .icon-circle { width: 80px; height: 80px; background: #e8f5e9; color: #2e7d32; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 40px; margin: 0 auto 20px; }
    </style>
</head>
<body>

    <?php include 'student-header.php'; ?>

    <div class="status-card">
        <?php if(isset($success_msg)): ?>
            <div class="icon-circle">✓</div>
            <h2>Request Sent!</h2>
            <p><?= $success_msg ?></p>
            <p style="font-size: 0.9rem; color: #666;">Request ID: <strong><?= $newID ?></strong></p>
        <?php endif; ?>
        <br>
        <a href="ride-history.php" class="btn student" style="width: 90%;">View My History</a>
    </div>

</body>
</html>