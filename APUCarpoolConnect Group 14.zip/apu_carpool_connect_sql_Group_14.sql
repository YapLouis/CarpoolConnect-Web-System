-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Feb 15, 2026 at 02:58 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `apu_carpool_connect`
--

-- --------------------------------------------------------

--
-- Table structure for table `carbon_tracking_table`
--

CREATE TABLE `carbon_tracking_table` (
  `carbon_id` varchar(20) NOT NULL,
  `ride_id` varchar(20) NOT NULL,
  `distance` decimal(5,2) NOT NULL,
  `co2_saved` decimal(5,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `carbon_tracking_table`
--

INSERT INTO `carbon_tracking_table` (`carbon_id`, `ride_id`, `distance`, `co2_saved`) VALUES
('C001', 'R001', 1.00, 0.20),
('C002', 'R002', 7.57, 1.51);

-- --------------------------------------------------------

--
-- Table structure for table `carpool_request_table`
--

CREATE TABLE `carpool_request_table` (
  `request_id` varchar(20) NOT NULL,
  `ride_id` varchar(20) NOT NULL,
  `student_id` varchar(20) NOT NULL,
  `fare` decimal(5,2) NOT NULL,
  `status` enum('pending','approved','rejected') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `carpool_request_table`
--

INSERT INTO `carpool_request_table` (`request_id`, `ride_id`, `student_id`, `fare`, `status`) VALUES
('REQ001', 'R001', 'US002', 0.97, 'approved'),
('REQ002', 'R001', 'US003', 0.97, 'approved'),
('REQ003', 'R002', 'US002', 14.76, 'approved');

-- --------------------------------------------------------

--
-- Table structure for table `driver_detail_table`
--

CREATE TABLE `driver_detail_table` (
  `driver_id` varchar(20) NOT NULL,
  `license_number` varchar(20) NOT NULL,
  `car_model` varchar(50) NOT NULL,
  `plate_number` varchar(15) NOT NULL,
  `driver_rating` decimal(3,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `driver_detail_table`
--

INSERT INTO `driver_detail_table` (`driver_id`, `license_number`, `car_model`, `plate_number`, `driver_rating`) VALUES
('US004', '876523890173', 'Proton X50', 'VMN6790', 5.00),
('US005', '187654389027', 'Perodua Bezza', 'VGB6679', 5.00);

-- --------------------------------------------------------

--
-- Table structure for table `eco_points_table`
--

CREATE TABLE `eco_points_table` (
  `points_id` varchar(20) NOT NULL,
  `user_id` varchar(20) NOT NULL,
  `ride_id` varchar(20) NOT NULL,
  `points_earned` varchar(20) NOT NULL,
  `earned_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `eco_points_table`
--

INSERT INTO `eco_points_table` (`points_id`, `user_id`, `ride_id`, `points_earned`, `earned_at`) VALUES
('P001', 'US002', 'R001', '20', '2026-02-14 18:37:48'),
('P002', 'US003', 'R001', '20', '2026-02-14 18:37:48'),
('P003', 'US002', 'R002', '151', '2026-02-14 18:49:35');

-- --------------------------------------------------------

--
-- Table structure for table `location_table`
--

CREATE TABLE `location_table` (
  `location_id` varchar(20) NOT NULL,
  `location_name` varchar(255) NOT NULL,
  `latitude` decimal(10,8) NOT NULL,
  `longitude` decimal(11,8) NOT NULL,
  `location_type` enum('both') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `location_table`
--

INSERT INTO `location_table` (`location_id`, `location_name`, `latitude`, `longitude`, `location_type`) VALUES
('L001', 'APU Main Entrance', 3.05610000, 101.70010000, 'both'),
('L002', 'LRT Bukit Jalil', 3.05830000, 101.69140000, 'both'),
('L003', 'M Vertica', 3.11850000, 101.72730000, 'both'),
('L004', 'Casa Green', 3.06420000, 101.66420000, 'both');

-- --------------------------------------------------------

--
-- Table structure for table `ratings_table`
--

CREATE TABLE `ratings_table` (
  `rating_id` varchar(20) NOT NULL,
  `ride_id` varchar(20) NOT NULL,
  `student_id` varchar(20) NOT NULL,
  `driver_id` varchar(20) NOT NULL,
  `rating_score` int(1) NOT NULL CHECK (`rating_score` between 1 and 5),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ratings_table`
--

INSERT INTO `ratings_table` (`rating_id`, `ride_id`, `student_id`, `driver_id`, `rating_score`, `created_at`) VALUES
('RT001', 'R001', 'US002', 'US004', 5, '2026-02-14 18:38:18'),
('RT002', 'R001', 'US003', 'US004', 5, '2026-02-14 18:38:55'),
('RT003', 'R002', 'US002', 'US005', 5, '2026-02-14 18:49:59');

-- --------------------------------------------------------

--
-- Table structure for table `rides_table`
--

CREATE TABLE `rides_table` (
  `ride_id` varchar(20) NOT NULL,
  `driver_id` varchar(20) NOT NULL,
  `pickup_id` varchar(20) NOT NULL,
  `dropoff_id` varchar(20) NOT NULL,
  `departure_time` datetime NOT NULL,
  `total_seats` tinyint(4) NOT NULL,
  `ride_status` enum('active','completed','cancelled') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rides_table`
--

INSERT INTO `rides_table` (`ride_id`, `driver_id`, `pickup_id`, `dropoff_id`, `departure_time`, `total_seats`, `ride_status`) VALUES
('R001', 'US004', 'L001', 'L002', '2026-02-15 17:00:00', 2, 'completed'),
('R002', 'US005', 'L001', 'L003', '2026-02-17 17:45:00', 3, 'completed');

-- --------------------------------------------------------

--
-- Table structure for table `student_details_table`
--

CREATE TABLE `student_details_table` (
  `student_id` varchar(20) NOT NULL,
  `tp_number` varchar(20) NOT NULL,
  `emergency_contact` varchar(30) NOT NULL,
  `total_points` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student_details_table`
--

INSERT INTO `student_details_table` (`student_id`, `tp_number`, `emergency_contact`, `total_points`) VALUES
('US002', 'TP072378', '0186655389', 171),
('US003', 'TP086654', '0176644356', 20);

-- --------------------------------------------------------

--
-- Table structure for table `user_table`
--

CREATE TABLE `user_table` (
  `user_id` varchar(20) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone_number` varchar(30) NOT NULL,
  `role` enum('student','driver','admin') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_table`
--

INSERT INTO `user_table` (`user_id`, `full_name`, `email`, `password`, `phone_number`, `role`, `created_at`) VALUES
('US001', 'Admin', 'admin@mail.apu.edu.my', '$2y$10$tgFpX/gnLV/YSq.qgmBOOuV1jKeQtaJ..cGXT.Fq3DJdwBvVesMa.', '0187755641', 'admin', '2026-02-14 18:30:42'),
('US002', 'Mary', 'mary@mail.apu.edu.my', '$2y$10$OOwJczR5NgDBv8fJU9cF.ez1ko.zoZ/MHmbHe3hC0y47wogpjVZhq', '0126778950', 'student', '2026-02-14 18:31:56'),
('US003', 'Bob', 'bob@mail.apu.edu.my', '$2y$10$B2gtCZRJNqaPLg1wbL6mrOAE0qeIcsHmYf/.z8UPYM4yGnU/wjKD6', '0128667543', 'student', '2026-02-14 18:33:18'),
('US004', 'Ali', 'ali@mail.apu.edu.my', '$2y$10$IIDrHCeomMrBTFTs06eI4.BvLjzFcgqqNxb4b3k.mzYEW7tNv0tIa', '0187854951', 'driver', '2026-02-14 18:35:47'),
('US005', 'Kai', 'kai@mail.apu.edu.my', '$2y$10$S8tZc3N.JvUVZwI6MFxcdO/19S5CdxKe6oH46dPNoDUFy.XCYW5Qu', '0126648765', 'driver', '2026-02-14 18:46:32');

-- --------------------------------------------------------

--
-- Table structure for table `voucher_list_table`
--

CREATE TABLE `voucher_list_table` (
  `voucher_id` varchar(20) NOT NULL,
  `voucher_name` varchar(100) NOT NULL,
  `point_cost` int(11) NOT NULL,
  `stock_quantity` int(11) NOT NULL,
  `terms_conditions` text NOT NULL,
  `voucher_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `voucher_list_table`
--

INSERT INTO `voucher_list_table` (`voucher_id`, `voucher_name`, `point_cost`, `stock_quantity`, `terms_conditions`, `voucher_status`) VALUES
('V001', 'RM5 Cafeteria Meal Voucher ', 300, 45, 'Valid at Level 3 Cafeteria. One voucher per transaction. Non-refundable. Must present Student ID. Not valid with other promos. Expired vouchers are void.', 1),
('V002', 'Free Hot Coffee/Teh Tarik', 200, 19, 'Valid for any hot beverage under RM3.00. Redeemable at the beverage counter only. Non-transferable to other students. Subject to daily availability.', 1);

-- --------------------------------------------------------

--
-- Table structure for table `voucher_redemption_table`
--

CREATE TABLE `voucher_redemption_table` (
  `redemption_id` varchar(20) NOT NULL,
  `user_id` varchar(20) NOT NULL,
  `voucher_id` varchar(20) NOT NULL,
  `unique_code` varchar(50) NOT NULL,
  `redemption_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `redemption_status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `voucher_redemption_table`
--

INSERT INTO `voucher_redemption_table` (`redemption_id`, `user_id`, `voucher_id`, `unique_code`, `redemption_date`, `redemption_status`) VALUES
('RD001', 'US002', 'V001', 'APU-RD001-7B0B', '2026-02-14 18:41:52', 'unavailable');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `carbon_tracking_table`
--
ALTER TABLE `carbon_tracking_table`
  ADD PRIMARY KEY (`carbon_id`),
  ADD KEY `ride_id` (`ride_id`);

--
-- Indexes for table `carpool_request_table`
--
ALTER TABLE `carpool_request_table`
  ADD PRIMARY KEY (`request_id`),
  ADD KEY `ride_id` (`ride_id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `driver_detail_table`
--
ALTER TABLE `driver_detail_table`
  ADD PRIMARY KEY (`driver_id`),
  ADD UNIQUE KEY `license_number` (`license_number`),
  ADD UNIQUE KEY `plate_number` (`plate_number`),
  ADD KEY `driver_id` (`driver_id`);

--
-- Indexes for table `eco_points_table`
--
ALTER TABLE `eco_points_table`
  ADD PRIMARY KEY (`points_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `ride_id` (`ride_id`);

--
-- Indexes for table `location_table`
--
ALTER TABLE `location_table`
  ADD PRIMARY KEY (`location_id`);

--
-- Indexes for table `ratings_table`
--
ALTER TABLE `ratings_table`
  ADD PRIMARY KEY (`rating_id`),
  ADD UNIQUE KEY `one_rating_per_ride` (`ride_id`,`student_id`);

--
-- Indexes for table `rides_table`
--
ALTER TABLE `rides_table`
  ADD PRIMARY KEY (`ride_id`),
  ADD KEY `fk_rides_driver` (`driver_id`),
  ADD KEY `pickup_id` (`pickup_id`,`dropoff_id`),
  ADD KEY `fk_rides_dropoff` (`dropoff_id`);

--
-- Indexes for table `student_details_table`
--
ALTER TABLE `student_details_table`
  ADD PRIMARY KEY (`student_id`),
  ADD UNIQUE KEY `tp_number` (`tp_number`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `user_table`
--
ALTER TABLE `user_table`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `voucher_list_table`
--
ALTER TABLE `voucher_list_table`
  ADD PRIMARY KEY (`voucher_id`);

--
-- Indexes for table `voucher_redemption_table`
--
ALTER TABLE `voucher_redemption_table`
  ADD PRIMARY KEY (`redemption_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `voucher_id` (`voucher_id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `carbon_tracking_table`
--
ALTER TABLE `carbon_tracking_table`
  ADD CONSTRAINT `fk_carbon_ride` FOREIGN KEY (`ride_id`) REFERENCES `rides_table` (`ride_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `carpool_request_table`
--
ALTER TABLE `carpool_request_table`
  ADD CONSTRAINT `fk_request_ride` FOREIGN KEY (`ride_id`) REFERENCES `rides_table` (`ride_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_requests_student` FOREIGN KEY (`student_id`) REFERENCES `user_table` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `driver_detail_table`
--
ALTER TABLE `driver_detail_table`
  ADD CONSTRAINT `fk_driver_user` FOREIGN KEY (`driver_id`) REFERENCES `user_table` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `eco_points_table`
--
ALTER TABLE `eco_points_table`
  ADD CONSTRAINT `fk_points_ride` FOREIGN KEY (`ride_id`) REFERENCES `rides_table` (`ride_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_points_user` FOREIGN KEY (`user_id`) REFERENCES `user_table` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `rides_table`
--
ALTER TABLE `rides_table`
  ADD CONSTRAINT `fk_rides_driver` FOREIGN KEY (`driver_id`) REFERENCES `user_table` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_rides_dropoff` FOREIGN KEY (`dropoff_id`) REFERENCES `location_table` (`location_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_rides_pickup` FOREIGN KEY (`pickup_id`) REFERENCES `location_table` (`location_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `student_details_table`
--
ALTER TABLE `student_details_table`
  ADD CONSTRAINT `fk_student_user` FOREIGN KEY (`student_id`) REFERENCES `user_table` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `voucher_redemption_table`
--
ALTER TABLE `voucher_redemption_table`
  ADD CONSTRAINT `fk_redemption_user` FOREIGN KEY (`user_id`) REFERENCES `user_table` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_redemption_voucher` FOREIGN KEY (`voucher_id`) REFERENCES `voucher_list_table` (`voucher_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
